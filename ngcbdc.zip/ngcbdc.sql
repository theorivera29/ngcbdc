DROP TABLE IF EXISTS `accounts`;
CREATE TABLE `accounts` (
  `accounts_id` int(11) NOT NULL AUTO_INCREMENT,
  `accounts_fname` varchar(45) NOT NULL,
  `accounts_lname` varchar(45) NOT NULL,
  `accounts_username` varchar(45) NOT NULL,
  `accounts_password` varchar(45) NOT NULL,
  `accounts_type` varchar(45) NOT NULL,
  `accounts_email` varchar(45) NOT NULL,
  `accounts_deletable` varchar(45) NOT NULL,
  `accounts_status` varchar(45) NOT NULL,
  PRIMARY KEY (`accounts_id`),
  UNIQUE KEY `accounts_id_UNIQUE` (`accounts_id`),
  UNIQUE KEY `accounts_username_UNIQUE` (`accounts_username`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
LOCK TABLES `accounts` WRITE;
UNLOCK TABLES;

DROP TABLE IF EXISTS `projects`;
CREATE TABLE `projects` (
  `projects_id` int(11) NOT NULL,
  `projects_name` varchar(45) DEFAULT NULL,
  `projects_address` varchar(50) DEFAULT NULL,
  `projects_sdate` datetime DEFAULT NULL,
  `projects_edate` datetime DEFAULT NULL,
  `projects_status` varchar(45) DEFAULT NULL,
  `projects_mateng` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`projects_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
LOCK TABLES `projects` WRITE;
UNLOCK TABLES;

DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `categories_id` int(11) NOT NULL AUTO_INCREMENT,
  `categories_name` varchar(45) NOT NULL,
  `categories_project` varchar(45) NOT NULL,
  PRIMARY KEY (`categories_id`),
  UNIQUE KEY `categories_id_UNIQUE` (`categories_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
LOCK TABLES `categories` WRITE;
UNLOCK TABLES;

DROP TABLE IF EXISTS `unit`;
CREATE TABLE `unit` (
  `unit_id` int(11) NOT NULL AUTO_INCREMENT,
  `unit_name` varchar(45) NOT NULL,
  PRIMARY KEY (`unit_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
LOCK TABLES `unit` WRITE;
UNLOCK TABLES;

DROP TABLE IF EXISTS `materials`;
CREATE TABLE `materials` (
  `mat_id` int(11) NOT NULL AUTO_INCREMENT,
  `mat_name` varchar(45) NOT NULL,
  PRIMARY KEY (`mat_id`),
  UNIQUE KEY `mat_id_UNIQUE` (`mat_id`),
  UNIQUE KEY `mat_name_UNIQUE` (`mat_name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
LOCK TABLES `materials` WRITE;
UNLOCK TABLES;

DROP TABLE IF EXISTS `hauling`;
CREATE TABLE `hauling` (
  `hauling_id` int(11) NOT NULL AUTO_INCREMENT,
  `hauling_no` varchar(45) NOT NULL,
  `hauling_date` datetime NOT NULL,
  `hauling_deliverTo` varchar(45) NOT NULL,
  `hauling_hauledFrom` varchar(45) NOT NULL,
  `hauling_quantity` varchar(45) NOT NULL,
  `hauling_unit` varchar(45) NOT NULL,
  `hauling_matname` varchar(45) NOT NULL,
  `hauling_hauledBy` varchar(45) NOT NULL,
  `hauling_requestedBy` varchar(45) NOT NULL,
  `hauling_warehouseman` varchar(45) NOT NULL,
  `hauling_approvedBy` varchar(45) NOT NULL,
  `hauling_truckDetailsType` varchar(45) NOT NULL,
  `hauling_truckDetailsPlateNo` varchar(45) NOT NULL,
  `hauling_truckDetailsPO` varchar(45) NOT NULL,
  PRIMARY KEY (`hauling_id`),
  UNIQUE KEY `hauling_id_UNIQUE` (`hauling_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
LOCK TABLES `hauling` WRITE;
UNLOCK TABLES;

DROP TABLE IF EXISTS `logs`;
CREATE TABLE `logs` (
  `logs_id` int(11) NOT NULL AUTO_INCREMENT,
  `logs_datetime` datetime NOT NULL,
  `logs_activity` varchar(45) NOT NULL,
  `logs_logsOf` varchar(45) NOT NULL,
  PRIMARY KEY (`logs_id`),
  UNIQUE KEY `logs_id_UNIQUE` (`logs_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
LOCK TABLES `logs` WRITE;
UNLOCK TABLES;

DROP TABLE IF EXISTS `matinfo`;
CREATE TABLE `matinfo` (
  `matinfo_id` int(11) NOT NULL AUTO_INCREMENT,
  `matinfo_prevStock` int(11) NOT NULL,
  `matinfo_project` int(11) NOT NULL,
  `matinfo_notif` varchar(45) NOT NULL,
  `currentQuantity` varchar(45) NOT NULL,
  `matinfo_matname` int(11) NOT NULL,
  PRIMARY KEY (`matinfo_id`),
  UNIQUE KEY `matinfo_id_UNIQUE` (`matinfo_id`),
  KEY `matname_idx` (`matinfo_matname`),
  KEY `matproject_idx` (`matinfo_project`),
  CONSTRAINT `matname` FOREIGN KEY (`matinfo_matname`) REFERENCES `materials` (`mat_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `matproject` FOREIGN KEY (`matinfo_project`) REFERENCES `projects` (`projects_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
LOCK TABLES `matinfo` WRITE;
INSERT INTO `matinfo` VALUES (1,100,1,'50','70',1),(2,300,3,'50','150',1);
UNLOCK TABLES;

DROP TABLE IF EXISTS `projmateng`;
CREATE TABLE `projmateng` (
  `projmateng_id` int(11) NOT NULL AUTO_INCREMENT,
  `projmateng_project` varchar(45) NOT NULL,
  `projmateng_mateng` varchar(45) NOT NULL,
  PRIMARY KEY (`projmateng_id`),
  UNIQUE KEY `projacc_id_UNIQUE` (`projmateng_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
LOCK TABLES `projmateng` WRITE;
UNLOCK TABLES;

DROP TABLE IF EXISTS `request`;
CREATE TABLE `request` (
  `req_id` int(11) NOT NULL AUTO_INCREMENT,
  `req_username` varchar(45) NOT NULL,
  `req_date` datetime NOT NULL,
  PRIMARY KEY (`req_id`),
  UNIQUE KEY `req_id_UNIQUE` (`req_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
LOCK TABLES `request` WRITE;
UNLOCK TABLES;

DROP TABLE IF EXISTS `todo`;
CREATE TABLE `todo` (
  `todo_id` int(11) NOT NULL AUTO_INCREMENT,
  `todo_date` datetime NOT NULL,
  `todo_task` varchar(45) NOT NULL,
  `todo_status` varchar(45) NOT NULL,
  `todoOf` varchar(45) NOT NULL,
  PRIMARY KEY (`todo_id`),
  UNIQUE KEY `todo_id_UNIQUE` (`todo_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
LOCK TABLES `todo` WRITE;
UNLOCK TABLES;

DROP TABLE IF EXISTS `usagein`;
CREATE TABLE `usagein` (
  `usagein_id` int(11) NOT NULL AUTO_INCREMENT,
  `usagein_date` datetime NOT NULL,
  `usagein_quantity` varchar(45) NOT NULL,
  `usagein_unit` varchar(45) NOT NULL,
  `pulledOutBy` varchar(45) NOT NULL,
  `usagein_areaOfUsage` varchar(45) NOT NULL,
  `usagein_matname` varchar(45) NOT NULL,
  PRIMARY KEY (`usagein_id`),
  UNIQUE KEY `usagein_id_UNIQUE` (`usagein_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
LOCK TABLES `usagein` WRITE;
UNLOCK TABLES;

DROP TABLE IF EXISTS `deliveredin`;
CREATE TABLE `deliveredin` (
  `deliveredin_id` int(11) NOT NULL AUTO_INCREMENT,
  `deliveredin_date` datetime NOT NULL,
  `deliveredin_quantity` varchar(45) NOT NULL,
  `deliveredin_unit` varchar(45) NOT NULL,
  `suppliedBy` varchar(45) NOT NULL,
  `deliveredin_matname` varchar(45) NOT NULL,
  PRIMARY KEY (`deliveredin_id`),
  UNIQUE KEY `deliveredin_id_UNIQUE` (`deliveredin_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
LOCK TABLES `deliveredin` WRITE;
UNLOCK TABLES;