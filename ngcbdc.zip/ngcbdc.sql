DROP TABLE IF EXISTS `accounts`;
CREATE TABLE `accounts` (
  `accounts_id` int(11) NOT NULL AUTO_INCREMENT,
  `accounts_fname` varchar(45) NOT NULL,
  `accounts_lname` varchar(45) NOT NULL,
  `accounts_username` varchar(45) NOT NULL,
  `accounts_password` varchar(150) NOT NULL,
  `accounts_type` varchar(45) NOT NULL,
  `accounts_email` varchar(45) NOT NULL,
  `accounts_deletable` varchar(45) NOT NULL,
  `accounts_status` varchar(45) NOT NULL,
  PRIMARY KEY (`accounts_id`),
  UNIQUE KEY `accounts_id_UNIQUE` (`accounts_id`),
  UNIQUE KEY `accounts_username_UNIQUE` (`accounts_username`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
LOCK TABLES `accounts` WRITE;
INSERT INTO `accounts` VALUES (1,'materials','engineer','materials_engineer','$2y$10$9KWB6zo6BUhC2U9qWyIkJuwfLMDK6GnoctpYbaxCpT4IuBYHyUjZy','Materials Engineer','mateng@gmail.com','no','active'),(2,'admin','admin','admin','$2y$10$7MiO1behDuzQBbUdNL1riOjO7eDnOIcbL2J4DWIvec/cRMCZduRCm','Admin','admin@gmail.com','no','active'),(3,'View','Only','view_only','$2y$10$xkl8OZp95hIZNkSUfKul5.wYUVZvNDJK12PdMrhmO285A8ogM6/c2','View Only','viewonly@gmail.com','no','active');
UNLOCK TABLES;

DROP TABLE IF EXISTS `projects`;
CREATE TABLE `projects` (
  `projects_id` int(11) NOT NULL AUTO_INCREMENT,
  `projects_name` varchar(45) NOT NULL,
  `projects_address` varchar(50) NOT NULL,
  `projects_sdate` date NOT NULL,
  `projects_edate` date NOT NULL,
  `projects_status` varchar(45) NOT NULL,
  PRIMARY KEY (`projects_id`),
  UNIQUE KEY `projects_id_UNIQUE` (`projects_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
LOCK TABLES `projects` WRITE;
INSERT INTO `projects` VALUES (1,'SM Baguio Expansion','Luneta Hill, Baguio City','2017-03-17','2019-03-17','open'),(2,'SOGO Hotel Baguio','Bakakeng, Baguio City','2018-05-13','2020-05-13','closed'),(3,'Hyatt Hotel Baguio','Engineers Hill, Baguio City','2015-08-11','2018-08-11','open');
UNLOCK TABLES;

DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `categories_id` int(11) NOT NULL AUTO_INCREMENT,
  `categories_name` varchar(45) NOT NULL,
  PRIMARY KEY (`categories_id`),
  UNIQUE KEY `categories_id_UNIQUE` (`categories_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
LOCK TABLES `categories` WRITE;
INSERT INTO `categories` VALUES (1,'Blades'),(2,'Formworks'),(3,'Electrical'),(4,'Plumbing'),(5,'Lubricants'),(6,'Table Forms'),(7,'Office'),(8,'Tower Crane'),(9,'Consumables'),(10,'Heavy Equipment'),(11,'Others');
UNLOCK TABLES;

DROP TABLE IF EXISTS `unit`;
CREATE TABLE `unit` (
  `unit_id` int(11) NOT NULL AUTO_INCREMENT,
  `unit_name` varchar(45) NOT NULL,
  PRIMARY KEY (`unit_id`),
  UNIQUE KEY `unit_id_UNIQUE` (`unit_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
LOCK TABLES `unit` WRITE;
INSERT INTO `unit` VALUES (1,'pcs'),(2,'mtrs'),(3,'rolls'),(4,'set');
UNLOCK TABLES;

DROP TABLE IF EXISTS `catproj`;
CREATE TABLE `catproj` (
  `catproj_project` int(11) NOT NULL,
  `catproj_categories` int(11) NOT NULL,
  KEY `catproj_proj_idx` (`catproj_project`),
  KEY `catproj_categ_idx` (`catproj_categories`),
  CONSTRAINT `catproj_categ` FOREIGN KEY (`catproj_categories`) REFERENCES `categories` (`categories_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `catproj_proj` FOREIGN KEY (`catproj_project`) REFERENCES `projects` (`projects_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
LOCK TABLES `catproj` WRITE;
UNLOCK TABLES;

DROP TABLE IF EXISTS `materials`;
CREATE TABLE `materials` (
  `mat_id` int(11) NOT NULL AUTO_INCREMENT,
  `mat_name` varchar(65) NOT NULL,
  `mat_categ` int(11) NOT NULL,
  `mat_unit` int(11) NOT NULL,
  PRIMARY KEY (`mat_id`),
  UNIQUE KEY `mat_id_UNIQUE` (`mat_id`),
  UNIQUE KEY `mat_name_UNIQUE` (`mat_name`),
  KEY `matcateg_idx` (`mat_categ`),
  KEY `matunit_idx` (`mat_unit`),
  CONSTRAINT `matcateg` FOREIGN KEY (`mat_categ`) REFERENCES `categories` (`categories_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `matunit` FOREIGN KEY (`mat_unit`) REFERENCES `unit` (`unit_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;
LOCK TABLES `materials` WRITE;
INSERT INTO `materials` VALUES (1,'A-Clamp Assymbly',1,1),(2,'Bolt & Nut 1/2x4 w/ washer',1,1),(3,'Grounding Wire 60mmsg',2,2),(4,'THHN Wire 3.5mm2',2,3),(5,'Bushing 3\"',3,1),(6,'PVC Pipe 3\" x 3m',3,1),(7,'Cup Brush 4\"',4,1),(8,'Cutting Disc 4\"',4,1),(9,'Beam Hanger',6,1),(10,'Table Form T1 (3.353 x 6.990)',6,1),(11,'Christmas Gift',11,1),(12,'Anchor Bolt w/ Nut 20mm x 50mm',11,1);
UNLOCK TABLES;

DROP TABLE IF EXISTS `hauling`;
CREATE TABLE `hauling` (
  `hauling_id` int(11) NOT NULL AUTO_INCREMENT,
  `hauling_no` int(11) NOT NULL,
  `hauling_date` date NOT NULL,
  `hauling_deliverTo` varchar(45) NOT NULL,
  `hauling_hauledFrom` varchar(45) NOT NULL,
  `hauling_quantity` int(11) NOT NULL,
  `hauling_unit` int(11) NOT NULL,
  `hauling_matname` int(11) NOT NULL,
  `hauling_hauledBy` varchar(45) NOT NULL,
  `hauling_requestedBy` varchar(45) NOT NULL,
  `hauling_warehouseman` varchar(45) NOT NULL,
  `hauling_approvedBy` varchar(45) NOT NULL,
  `hauling_truckDetailsType` varchar(45) NOT NULL,
  `hauling_truckDetailsPlateNo` varchar(45) NOT NULL,
  `hauling_truckDetailsPO` varchar(45) NOT NULL,
  `hauling_truckDetailsHaulerDR` varchar(45) NOT NULL,
  PRIMARY KEY (`hauling_id`),
  UNIQUE KEY `hauling_id_UNIQUE` (`hauling_id`),
  KEY `haulingmatname_idx` (`hauling_matname`),
  KEY `haulingunit_idx` (`hauling_unit`),
  CONSTRAINT `haulingmatname` FOREIGN KEY (`hauling_matname`) REFERENCES `materials` (`mat_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `haulingunit` FOREIGN KEY (`hauling_unit`) REFERENCES `unit` (`unit_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
LOCK TABLES `hauling` WRITE;
INSERT INTO `hauling` VALUES (1,1,'2019-03-03','Rimando Inc.','NGCB Expansion Site',250,1,1,'Caryl Oficiar','Ray Servidad','Vincent Ibalio','Jam Rocafort','HOWO Dump Truck','QWE 1234','171036'),(2,221,'2019-04-04','Servidad Inc.','SOGO Hotel Baguio',100,1,1,'Vince Tagudar','Theo Rivera','Vincent Ibalio','Jam Rocafort','HOWO Dump Truck','QWE 5687','171725'),(3,122,'2019-05-05','Vinluan Corp.','NGCB Expansion Site',300,2,1,'Vincent Ibalio','Jam Rocafort','Vincent Ibalio','Jam Rocafort','Armored Truck','ASA 1234','123467');
UNLOCK TABLES;

DROP TABLE IF EXISTS `logs`;
CREATE TABLE `logs` (
  `logs_id` int(11) NOT NULL AUTO_INCREMENT,
  `logs_datetime` datetime NOT NULL,
  `logs_activity` varchar(45) NOT NULL,
  `logs_logsOf` varchar(45) NOT NULL,
  PRIMARY KEY (`logs_id`),
  UNIQUE KEY `logs_id_UNIQUE` (`logs_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
LOCK TABLES `logs` WRITE;
INSERT INTO `logs` VALUES (1,'2019-04-09 14:53:30','Created Material','1'),(2,'2019-03-18 11:27:40','Created Hauling','1');
UNLOCK TABLES;

DROP TABLE IF EXISTS `matinfo`;
CREATE TABLE `matinfo` (
  `matinfo_id` int(11) NOT NULL AUTO_INCREMENT,
  `matinfo_prevStock` int(11) NOT NULL,
  `matinfo_project` int(11) NOT NULL,
  `matinfo_notif` varchar(45) NOT NULL,
  `currentQuantity` varchar(45) NOT NULL,
  `matinfo_matname` int(11) NOT NULL,
  PRIMARY KEY (`matinfo_id`),
  UNIQUE KEY `matinfo_id_UNIQUE` (`matinfo_id`),
  KEY `matname_idx` (`matinfo_matname`),
  KEY `matproject_idx` (`matinfo_project`),
  CONSTRAINT `matname` FOREIGN KEY (`matinfo_matname`) REFERENCES `materials` (`mat_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `matproject` FOREIGN KEY (`matinfo_project`) REFERENCES `projects` (`projects_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
LOCK TABLES `matinfo` WRITE;
INSERT INTO `matinfo` VALUES (1,100,1,'50','70',1),(2,300,3,'50','150',1);
UNLOCK TABLES;

DROP TABLE IF EXISTS `projmateng`;
CREATE TABLE `projmateng` (
  `projmateng_id` int(11) NOT NULL AUTO_INCREMENT,
  `projmateng_project` int(11) NOT NULL,
  `projmateng_mateng` int(11) NOT NULL,
  PRIMARY KEY (`projmateng_id`),
  UNIQUE KEY `projacc_id_UNIQUE` (`projmateng_id`),
  KEY `projmateng_of_idx` (`projmateng_mateng`),
  KEY `projmateng_proj_idx` (`projmateng_project`),
  CONSTRAINT `projmateng_of` FOREIGN KEY (`projmateng_mateng`) REFERENCES `accounts` (`accounts_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `projmateng_proj` FOREIGN KEY (`projmateng_project`) REFERENCES `projects` (`projects_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
LOCK TABLES `projmateng` WRITE;
INSERT INTO `projmateng` VALUES (1,1,1);
UNLOCK TABLES;

DROP TABLE IF EXISTS `request`;
CREATE TABLE `request` (
  `req_id` int(11) NOT NULL AUTO_INCREMENT,
  `req_username` int(11) NOT NULL,
  `req_date` date NOT NULL,
  `req_status` varchar(45) NOT NULL,
  PRIMARY KEY (`req_id`),
  UNIQUE KEY `req_id_UNIQUE` (`req_id`),
  KEY `req_uname_idx` (`req_username`),
  CONSTRAINT `req_uname` FOREIGN KEY (`req_username`) REFERENCES `accounts` (`accounts_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
LOCK TABLES `request` WRITE;
INSERT INTO `request` VALUES (1,1,'2019-04-14','declined'),(2,3,'2019-07-23','accepted'),(3,1,'2019-05-13','pending');
UNLOCK TABLES;

DROP TABLE IF EXISTS `todo`;
CREATE TABLE `todo` (
  `todo_id` int(11) NOT NULL,
  `todo_date` date NOT NULL,
  `todo_task` varchar(45) NOT NULL,
  `todo_status` varchar(45) NOT NULL,
  `todoOf` int(11) NOT NULL,
  PRIMARY KEY (`todo_id`),
  UNIQUE KEY `todo_id_UNIQUE` (`todo_id`),
  KEY `todo_of_idx` (`todoOf`),
  CONSTRAINT `todo_of` FOREIGN KEY (`todoOf`) REFERENCES `accounts` (`accounts_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
LOCK TABLES `todo` WRITE;
INSERT INTO `todo` VALUES (1,'2019-05-24','Delivery Day','done',1),(2,'2019-05-31','Hauling','in progress',1);
UNLOCK TABLES;

DROP TABLE IF EXISTS `usagein`;
CREATE TABLE `usagein` (
  `usagein_id` int(11) NOT NULL AUTO_INCREMENT,
  `usagein_date` datetime NOT NULL,
  `usagein_quantity` varchar(45) NOT NULL,
  `usagein_unit` int(11) NOT NULL,
  `pulledOutBy` varchar(45) NOT NULL,
  `usagein_areaOfUsage` varchar(45) NOT NULL,
  `usagein_matname` int(11) NOT NULL,
  PRIMARY KEY (`usagein_id`),
  UNIQUE KEY `usagein_id_UNIQUE` (`usagein_id`),
  KEY `usageunit_idx` (`usagein_unit`),
  KEY `usagematname_idx` (`usagein_matname`),
  CONSTRAINT `usagematname` FOREIGN KEY (`usagein_matname`) REFERENCES `materials` (`mat_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `usageunit` FOREIGN KEY (`usagein_unit`) REFERENCES `unit` (`unit_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
LOCK TABLES `usagein` WRITE;
INSERT INTO `usagein` VALUES (1,'2019-03-21 00:00:00','3',1,'Laroza','SM B-up',1),(2,'2019-03-03 00:00:00','34',1,'Dulce','PH-2',1),(3,'2019-03-05 00:00:00','45',1,'Bisaya','PH-2 B-3',1),(4,'2019-03-08 00:00:00','17',2,'Vinaya','Foot',1),(5,'2019-03-07 00:00:00','59',1,'Pepito','B-up',1),(6,'2019-03-06 00:00:00','69',1,'Pepito','PH-1 B-up',1);
UNLOCK TABLES;

DROP TABLE IF EXISTS `deliveredin`;
CREATE TABLE `deliveredin` (
  `deliveredin_id` int(11) NOT NULL AUTO_INCREMENT,
  `deliveredin_date` date NOT NULL,
  `deliveredin_quantity` varchar(45) NOT NULL,
  `deliveredin_unit` int(11) NOT NULL,
  `suppliedBy` varchar(45) NOT NULL,
  `deliveredin_matname` int(11) NOT NULL,
  PRIMARY KEY (`deliveredin_id`),
  UNIQUE KEY `deliveredin_id_UNIQUE` (`deliveredin_id`),
  KEY `deliv_matname_idx` (`deliveredin_matname`),
  KEY `deliv_unit_idx` (`deliveredin_unit`),
  CONSTRAINT `deliveredmatname` FOREIGN KEY (`deliveredin_matname`) REFERENCES `materials` (`mat_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `deliveredunit` FOREIGN KEY (`deliveredin_unit`) REFERENCES `unit` (`unit_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
LOCK TABLES `deliveredin` WRITE;
INSERT INTO `deliveredin` VALUES (1,'2019-08-11','350',1,'Rimando Corp.',1),(2,'2019-06-12','69',2,'Servidad Corp.',2),(3,'2019-05-25','95',1,'LeBron Corp.',1),(4,'2019-04-28','100',1,'Rimando Corp.',1);
UNLOCK TABLES;