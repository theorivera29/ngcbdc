DROP TABLE IF EXISTS `accounts`;
CREATE TABLE `accounts` (
  `accounts_id` int(11) NOT NULL AUTO_INCREMENT,
  `accounts_fname` varchar(45) NOT NULL,
  `accounts_lname` varchar(45) NOT NULL,
  `accounts_username` varchar(45) NOT NULL,
  `accounts_password` varchar(150) NOT NULL,
  `accounts_type` varchar(45) NOT NULL,
  `accounts_email` varchar(45) NOT NULL,
  `accounts_deletable` varchar(45) NOT NULL,
  `accounts_status` varchar(45) NOT NULL,
  PRIMARY KEY (`accounts_id`),
  UNIQUE KEY `accounts_id_UNIQUE` (`accounts_id`),
  UNIQUE KEY `accounts_username_UNIQUE` (`accounts_username`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;
LOCK TABLES `accounts` WRITE;
INSERT INTO `accounts` VALUES (1,'materials','engineer','materials_engineer','$2y$10$9KWB6zo6BUhC2U9qWyIkJuwfLMDK6GnoctpYbaxCpT4IuBYHyUjZy','Materials Engineer','mateng@gmail.com','no','active'),(2,'admin','admin','admin','$2y$10$7MiO1behDuzQBbUdNL1riOjO7eDnOIcbL2J4DWIvec/cRMCZduRCm','Admin','admin@gmail.com','no','active'),(3,'View','Only','view_only','$2y$10$xkl8OZp95hIZNkSUfKul5.wYUVZvNDJK12PdMrhmO285A8ogM6/c2','View Only','viewonly@gmail.com','no','active'),(4,'Ray Oliver','Servidad','r_servidad','benzservidad','Materials Engineer','rservidad@gmail.com','yes','active'),(5,'Jonelle','Carino','jonellec2','carinojonelle','View Only','jonellecarino12@gmail.com','yes','active'),(6,'Caryl Marie','Oficiar','cmsoficiar','carylmarie12','Materials Engineer','mariecaryl19@gmail.com','yes','active'),(7,'Jam Spica','Rocafort','jamspicaa20','jamspicarocafort','View Only','jspica25@gmail.com','yes','active'),(8,'Theo Michael Kenneth','Rivera','trivera','theorivera','Materials Engineer','tmkrivera@gmail.com','yes','inactive'),(9,'Mikka','Tuguinay','tuguinaymikka12','mikkatuguinay123','View Only','mikkatuguinay@gmail.com','yes','inactive'),(10,'Harold Angelo','Vinluan','har_vinluan','family2010','Materials Engineer','haroldangelo@gmail.com','yes','inactive'),(11,'Vincent','Ibalio','ibaliov','kobeparas','View Only','vincentibalio13@gmail.com','yes','inactive'),(12,'Wanda','Maximoff','wandamax08','visionislove69','Materials Engineer','wmaximoff@gmail.com','yes','active'),(13,'Tony','Stark','starktony','pepperforever08','View Only','iamironman@gmail.com','yes','inactive'),(14,'Gal','Gadot','gadotgal13','crushkosibenzlovelove','Materials Engineer','ggadot13@gmail.com','yes','active'),(15,'Mark','Tabinas','madtabinas','limangsegundo','View Only','mtabinas@gmail.com','yes','inactive');
UNLOCK TABLES;
DROP TABLE IF EXISTS `projects`;
CREATE TABLE `projects` (
  `projects_id` int(11) NOT NULL AUTO_INCREMENT,
  `projects_name` varchar(45) NOT NULL,
  `projects_address` varchar(50) NOT NULL,
  `projects_sdate` date NOT NULL,
  `projects_edate` date NOT NULL,
  `projects_status` varchar(45) NOT NULL,
  PRIMARY KEY (`projects_id`),
  UNIQUE KEY `projects_id_UNIQUE` (`projects_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;
LOCK TABLES `projects` WRITE;
INSERT INTO `projects` VALUES (1,'SM Baguio Expansion','Luneta Hill, Baguio City','2017-03-17','2019-03-17','open'),(2,'SOGO Hotel Baguio','Bakakeng, Baguio City','2018-05-13','2020-05-13','closed'),(3,'Hyatt Hotel Baguio','Engineers Hill, Baguio City','2015-08-11','2018-08-11','open'),(4,'SOGO Hotel Dagupan','Bonuan Gueset, Dagupan City','2019-05-05','2019-10-05','open'),(5,'Skyranch Baguio','Luneta Hill, Baguio City','2018-01-03','2019-11-25','open'),(6,'SM Dagupan','Mayombo St., Dagupan City','2018-12-27','2019-12-27','open'),(7,'PMA Warehouse','Loakan Road, Baguio City','2020-04-12','2021-01-01','open'),(8,'S&R Baguio ','Bakakeng Rd., Baguio City','2019-05-05','2019-07-11','open'),(9,'Disneyland Baguio','La Trinidad, Baguio City','2011-02-14','2015-02-14','closed'),(10,'7 Wonders Waterpark','Bonuan Binloc, Dagupan City','2012-07-08','2013-06-21','closed'),(11,'SLU Gymnasium','Bonifacio St., Baguio City','2015-03-25','2014-05-05','closed'),(12,'SLU Swimming Pool','Bakakeng Rd., Baguio City','2019-01-25','2019-08-08','open');
UNLOCK TABLES;
DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `categories_id` int(11) NOT NULL AUTO_INCREMENT,
  `categories_name` varchar(45) NOT NULL,
  PRIMARY KEY (`categories_id`),
  UNIQUE KEY `categories_id_UNIQUE` (`categories_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
LOCK TABLES `categories` WRITE;
INSERT INTO `categories` VALUES (1,'Blades'),(2,'Formworks'),(3,'Electrical'),(4,'Plumbing'),(5,'Lubricants'),(6,'Table Forms'),(7,'Office'),(8,'Tower Crane'),(9,'Consumables'),(10,'Heavy Equipment'),(11,'Others');
UNLOCK TABLES;
DROP TABLE IF EXISTS `catproj`;
CREATE TABLE `catproj` (
  `catproj_project` int(11) NOT NULL,
  `catproj_categories` int(11) NOT NULL,
  KEY `catproj_proj_idx` (`catproj_project`),
  KEY `catproj_categ_idx` (`catproj_categories`),
  CONSTRAINT `catproj_categ` FOREIGN KEY (`catproj_categories`) REFERENCES `categories` (`categories_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `catproj_proj` FOREIGN KEY (`catproj_project`) REFERENCES `projects` (`projects_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
LOCK TABLES `catproj` WRITE;
UNLOCK TABLES;
DROP TABLE IF EXISTS `unit`;
CREATE TABLE `unit` (
  `unit_id` int(11) NOT NULL AUTO_INCREMENT,
  `unit_name` varchar(45) NOT NULL,
  PRIMARY KEY (`unit_id`),
  UNIQUE KEY `unit_id_UNIQUE` (`unit_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;
LOCK TABLES `unit` WRITE;
INSERT INTO `unit` VALUES (1,'pcs'),(2,'mtrs'),(3,'rolls'),(4,'set'),(5,'pairs'),(6,'sec'),(7,'pails'),(8,'units'),(9,'bags'),(10,'kg'),(11,'bxs'),(12,'drums'),(13,'cyl'),(14,'assy');
UNLOCK TABLES;
DROP TABLE IF EXISTS `materials`;
CREATE TABLE `materials` (
  `mat_id` int(11) NOT NULL AUTO_INCREMENT,
  `mat_name` varchar(65) NOT NULL,
  `mat_categ` int(11) NOT NULL,
  `mat_unit` int(11) NOT NULL,
  PRIMARY KEY (`mat_id`),
  UNIQUE KEY `mat_id_UNIQUE` (`mat_id`),
  UNIQUE KEY `mat_name_UNIQUE` (`mat_name`),
  KEY `matcateg_idx` (`mat_categ`),
  KEY `matunit_idx` (`mat_unit`),
  CONSTRAINT `matcateg` FOREIGN KEY (`mat_categ`) REFERENCES `categories` (`categories_id`) ON UPDATE CASCADE,
  CONSTRAINT `matunit` FOREIGN KEY (`mat_unit`) REFERENCES `unit` (`unit_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=319 DEFAULT CHARSET=latin1;
LOCK TABLES `materials` WRITE;
INSERT INTO `materials` VALUES (1,'Screwdriver',1,1),(2,'Plaster',1,1),(3,'Adobe',1,1),(4,'Wattle',1,1),(5,'Angle Bar 6mmx1.5x6m',9,1),(6,'Armorply 4x8x1/2',9,1),(7,'Asphalt Sealant ',9,7),(8,'Blind Rivets',9,11),(9,'Caution tape 3x300m',9,3),(10,'Counter Sunk',9,1),(11,'Epoxy Bond A&B',9,4),(12,'Form Lumber 2x2x8',9,1),(13,'Form Lumber 2x2x10',9,1),(14,'Form Lumber 2x2x12',9,1),(15,'Form Lumber 2x2x16',9,1),(16,'GI Wire',9,10),(17,'I-Beam (12x4.4,5,5.4)(10x3.0,3.15)',9,1),(18,'I-Rib',9,1),(19,'Louver Block',9,1),(20,'Metal Strip',9,1),(21,'Paint - Traffic Yellow',9,1),(22,'P.E Pipe 1/2x90m',9,3),(23,'P.E Pipe 3/4x90m',9,3),(24,'Plywood Ord.1/2 X 4 X 8',9,1),(25,'Pointed Chisel',9,1),(26,'Polyethylene Sheet',9,3),(27,'Sheet Asstd. Spandex (USED) (YERO)',9,1),(28,'Shear Wall 2.70x3.0m',9,4),(29,'Sika Antisol',9,12),(30,'Styropor 4X8X1/2',9,1),(31,'Welding Holder 300A',9,1),(32,'Welding Holder 500A',9,1),(33,'Welding Rod E6013',9,11),(34,'ATF',5,7),(35,'Gear Oil',5,7),(36,'Grease MP3',5,7),(37,'Hydraulic Oil AW68',5,7),(38,'Oil 40',5,7),(39,'Oil 140',5,7),(40,'Petrogresase MP3',5,7),(41,'Backhoe w/ battery',10,8),(42,'Backhoe (MINI)',10,8),(43,'Bar Bender 36mm',10,8),(44,'Bar Bender 42mm',10,8),(45,'Bar Cutter 36mm',10,8),(46,'Breaker w/ Moil Point',10,8),(47,'Bulldozer',10,8),(48,'Busbar Gutter (.40 X .40 X 2.40) 160A 3P',10,8),(49,'Chain Block 5T',10,8),(50,'Chain Block 10T',10,8),(51,'Chipping Hammer',10,8),(52,'Concrete Cutter-Mechanical',10,8),(53,'Cut-Off Wheel 14\" (DEWALT)',10,8),(54,'Dump Box',10,8),(55,'Edger 4\"',10,8),(56,'Electric Bagger Mixer',10,8),(57,'Electric Bar Bender 32 mm',10,8),(58,'Electric Bar Bender 36 mm',10,8),(59,'Electric Bar Bender 36mm',10,8),(60,'Electric Bar Cutter 42mm',10,8),(61,'Electric Pressure Washer',10,8),(62,'Electric Vibrator w/ Hose',10,8),(63,'Exhaust Fan',10,8),(64,'Fire Extinguisher',10,13),(65,'Fire Hose 3\" X 20m',10,3),(66,'Fogging Machine',10,8),(67,'Fuel Filter',10,1),(68,'Fuel Pump for TC Light',10,1),(69,'Fuel/Water Separator',10,1),(70,'Beam Bottom Armorply 0.25X2.44m',6,1),(71,'Beam Bottom Armorply 0.30X2.44m',6,1),(72,'Beam Bottom Armorply 0.40X2.44m',6,1),(73,'Beam Bottom Armorply 0.50X2.44m',6,1),(74,'Beam Bottom MS Plate 0.20X2.44m',6,1),(75,'Beam Bottom MS Plate 0.30X2.44m',6,1),(76,'Beam Clamp',6,1),(77,'Beam Hanger',6,1),(78,'Beam siding .61X2.44m',6,1),(79,'Beam siding .658X2.44m',6,1),(80,'Beam siding .703X2.44m',6,1),(81,'Beam siding .805X2.44m',6,1),(82,'Beam siding 1.004X2.44m',6,1),(83,'Beam Truss 0.30x6m',6,1),(84,'Chamfer Hinge .20-.50',6,1),(85,'Chamfer Hinge 1.12',6,1),(86,'Chamfer Hinge 2.44',6,1),(87,'Connecting Bridge',6,1),(88,'Counter Sunkss',6,1),(89,'EXT. Pipe',6,1),(90,'EXT. POST 1-1.5m',6,1),(91,'EXT. Post Yellow',6,1),(92,'KST Head',6,1),(93,'Modified KST Head',6,1),(94,'Props Connector',6,1),(95,'Table Form (2.2X7.040)',6,4),(96,'Table Form T1 (3.353 X 6.990)',6,4),(101,'Table Form T2 (3.543 X 6.990)',6,4),(102,'Table Form T3 (3.543 X 8.271)',6,4),(103,'Table Form T4 (3.446 X 7.040)',6,4),(104,'Table Form T5 (3.239 X 7.040)',6,4),(105,'Table Form T7 (2.526 X 7.040)',6,4),(106,'Table Form T8 (3.046 X 7.040)',6,4),(107,'Table Form T9 (2.200 X 7.040)',6,4),(108,'Table Form T10 (2.200 X 6.265)',6,4),(109,'Table Form T12 (2.44 X 3.649)',6,4),(110,'Table Form T13 (3.296 x 4.200)',6,4),(111,'Table Form T14 (3.251 X 3.296)',6,4),(112,'Table Form T16 (3.353 X 4.401)',6,4),(113,'Table Form T19 (2.463 X 4.294)',6,4),(114,'Table Form T20 (3.046 x 4.300)',6,4),(115,'Table Form T21 (3.239 X 4.300)',6,4),(116,'Table Form T22 (8.364 X 4.3005.949)',6,4),(117,'Telescopic Pipe',6,1),(118,'Triangular Posts 6m',6,1),(119,'Cup Brush 4\"',1,1),(120,'Cup Brush 7\"',1,1),(121,'Cup Wheel 7\"',1,1),(122,'Cutting Disc 4\"',1,1),(123,'Cutting Disc 7\"',1,1),(124,'Cut-Off Wheel 14\"',1,1),(125,'Cutting Disc 14\"',1,1),(126,'Diamond Cup Wheel 4\"',1,1),(127,'Grinding Disc 4\"',1,1),(128,'Grinding Disc 7\"',1,1),(129,'Genset (MEIDENSHA)',1,8),(130,'Grinder 4\" (BOSCH)',1,8),(131,'Grinder 4\" (DEWALT)',1,8),(132,'Hydraulic Motor',1,8),(133,'Manual Bar Bender',1,8),(134,'Manual Bar Cutter',1,8),(135,'Mechanical Pump 5HP',1,8),(136,'Mixing Board',1,1),(137,'Oil Filter',1,1),(138,'Orbit Fan (STANDARD)',1,8),(139,'Power Trowel',1,8),(140,'Pumpcrete Clamp for Sub Pump',1,1),(141,'Pumpcrete Pump 3M for Sub Pump',1,1),(142,'Ride on Compactor',1,8),(143,'SB1 Form ',1,1),(144,'Shovel w/o Handle (USED)',1,1),(145,'Skid Loader',1,8),(146,'Speed Cutter',1,8),(147,'Submersible Pump 2HP',1,8),(148,'Submersible Pump 7.5HP 3P',1,8),(149,'Transformable 61KVA',1,8),(150,'Transformable 150 KVA',1,8),(151,'Vibrator Engine Exen (NEW)',1,8),(152,'Vibrator w/ Hose',1,8),(153,'Vibrator Engine w/ Hose Wacker',1,8),(154,'Vibrator Hose Exen (NEW)',1,1),(155,'Vibrator Hose Exen ',1,1),(156,'Vibrator Hose Wacker',1,1),(157,'Welding Machine 500A',1,8),(158,'7.0 X 16 Interior',1,1),(159,'7.0 X 16 w/ Flab & Tube ',1,4),(160,'Hard Hat (WHTIE)',7,1),(161,'Monoblock Chair',7,1),(162,'Office Table',7,4),(163,'Rain Boots',7,5),(164,'Rain Coat',7,1),(165,'Safety Shoes',7,5),(166,'Safety Vest (NEON GREEN)',7,1),(167,'Toner (RICOH)',7,1),(168,'Two way Radio (CIGNUSV80)',7,8),(169,'Two way Radio (CIGNUSV85)',7,8),(170,'Uniform',7,1),(171,'Adaptor',8,6),(172,'Altivar 71',8,1),(173,'Base Mast (L-12x2.04x11.2m)',8,1),(174,'Black Stallion Rotating Cable 22mm',8,2),(175,'Boom',8,6),(176,'Cable Clamp',8,1),(177,'Cable for Hoisting 50m',8,3),(178,'Catwalk',8,1),(179,'Channel Pipe',8,1),(180,'Counter Jib',8,6),(181,'Counter Weight (1.45T)',8,1),(182,'Counter Weight (2.2T)',8,1),(183,'Counter Weight (2.25T)',8,1),(184,'Counter Weight Leibherr (280each)',8,1),(185,'Counter Weight Small Size',8,1),(186,'Flood Light (1000W) Housing',8,8),(187,'Hoisting Mechanism',8,8),(188,'Hook Block',8,1),(189,'Jib Boom W. Trolley Motor Cable Attached',8,1),(190,'Jib Section',8,1),(191,'Jib Section w/ Jib Nose 10m',8,1),(192,'Ladder for Tower Head',8,1),(193,'Leibherr Crane 2.13 x 2.13 . 4.10',8,6),(194,'Lighting Arrester ',8,8),(195,'Mast (4.13 X 2.03m)',8,6),(196,'Mast Bolt',8,1),(197,'A-Clamp Assymbly',2,1),(198,'A-Frame Korea',2,1),(199,'Base Jack .6m',2,1),(200,'Board Up 1.8 X 3.2m',2,1),(201,'Blot & Nut 1/2X2',2,1),(202,'Blot & Nut 1/2X4 w/ Washer',2,1),(203,'Blot & Nut 3/8X1.5 w/ 2 Washer',2,1),(204,'Blot & Nut 8X5\"',2,1),(205,'Bucket',2,1),(206,'Catch Board',2,1),(207,'Channel Beam Support',2,1),(208,'Circular Column Form80X480',2,4),(209,'Codalle 60 X 60',2,1),(210,'Codalle 60 X 90',2,1),(211,'Codalle 60 X 120',2,1),(212,'Codalle 60 X 150',2,1),(213,'Column Form (.70 x .70 x 4.88)',2,4),(214,'Column Form (.80 x .80 x 4.88)',2,4),(215,'Column Form (.95 x .95 x 3.90)',2,4),(216,'Column Form (1.0 x 1.0 x 4.88m)',2,4),(217,'Column Form (1.05 x 10.5 x 3.90)',2,4),(218,'Column Form (1.25 x 1.25 x 3.00)',2,4),(219,'Corner Cap',2,1),(220,'Cross Brace 2.2m',2,1),(221,'Couble Channel Shoring Jack (2.40m)',2,1),(222,'Ez Form ',2,1),(223,'Fab Channel',2,1),(224,'Fab Hook',2,1),(225,'fab Tie Rod',2,1),(226,'Fab Truss Asstd',2,1),(227,'Fence Tube 1-2m',2,1),(228,'Fence Tube 2-3m',2,1),(229,'Fence Tube 5-6m',2,1),(230,'Fence Tube 6m',2,1),(231,'Fence Tube .90m',2,1),(232,'Fence Panel',2,1),(233,'Fix Props',2,1),(234,'Fix Tripod 10T',2,1),(235,'Form Bearer',2,1),(236,'H-Fram 1 X 2m',2,1),(237,'Joint Pin 1&1/4',2,1),(238,'Lifting Belt 6\" X 6m',2,1),(239,'Lifting Cable',2,4),(240,'Lifting Carriage',2,4),(241,'Loading Platform',2,4),(242,'Metal Panel Red 60 X 120',2,1),(243,'Metal Panel Red 60 X 150',2,1),(244,'Panel Clip',2,1),(245,'Panel Clip (NEW)',2,1),(246,'R-24 Bolt 1/2X9\"',2,1),(247,'R-24 Bolt 1/2X11.5\"',2,1),(248,'Safety Bracket for Column',2,1),(249,'Shoring Jack 5T',2,1),(250,'Shoring Jack 10T',2,1),(251,'Shoring Jack 10T (NEW)',2,1),(252,'Shoring Jack 10T (4.1m)',2,1),(253,'Shoring Jack 10T (5.5m)',2,1),(254,'Shoring Jack (4.6m) 30T',2,1),(255,'Shoring Jack Adaptor',2,1),(256,'Shoring Jack Joist with Bearing Plate',2,1),(257,'Shoring Wrench',2,1),(258,'Sqaure Pipe 2-3m',2,1),(259,'Sqaure Pipe 6m',2,1),(260,'Step Ladder',2,1),(261,'Step Landing',2,1),(262,'Swivel Camp',2,1),(263,'Tie Rod 12mm x 6m',2,1),(264,'Tie Rod 12mm x 6m (LOCAL)',2,1),(265,'Triangular Post 5m',2,1),(266,'Triangular Post 6m',2,1),(267,'Tripod-10T',2,1),(268,'Truss Plate 12mm',2,1),(269,'Truss Plate 17mm',2,1),(270,'U-Head .60m',2,1),(271,'Vertical Waler (ASSTD SIZE)',2,1),(272,'Wall Form 5x3 s2.27',2,4),(273,'Wall Form 3x2.24x2.27',2,4),(274,'Wedge Pin',2,1),(275,'Wheel Guard Form',2,4),(276,'Wing Nut 12mm',2,1),(277,'Wing Nut 17mm LOCAL',2,1),(278,'Air Circuit Breaket 160A 3P',3,8),(279,'Battery 35M for BD#04',3,1),(280,'Circuit Breaker 20AMP',3,8),(281,'Circuit Breaker 250AMP',3,8),(282,'Circuit Breaker 400AMP',3,8),(283,'Circuit Breaker w/ Panel 250AMP',3,8),(284,'Circuit Breaker 1600A',3,8),(285,'Electric Circuit Breaker ',3,8),(286,'Flat Cord 14mm2',3,2),(287,'Fluorescent Housing 40W',3,1),(288,'Fluorescent Lamp w/Housing 40W',3,4),(289,'Grounding Wire 60mmsq',3,2),(290,'LED Light 100W',3,4),(291,'Main Breaker 1500Amp',3,8),(292,'Pilot Light',3,8),(293,'Royal Cord 3P 3.5mm2',3,2),(294,'Royal Cord SP 3.5mm3',3,2),(295,'Royal Cord 30mm X 150m',3,2),(296,'Starter for BD#04',3,14),(297,'THHN Wire 3.5mm2',3,3),(298,'THHN Wire 8.0mm2 150m',3,2),(299,'THHN Wire 14mm2',3,2),(300,'THHN Wire 30mm2',3,2),(301,'THHN Wire 500 mcm',3,2),(302,'Welding Cable',3,2),(303,'Bushing 3\"',4,1),(304,'Ent. Cap 3\"',4,1),(305,'Ground Lock Clamp',4,1),(306,'Ground Rod 1/2 X 10',4,1),(307,'Lock Nut 3\"',4,1),(308,'Lock Nut 3/4',4,1),(309,'PVC Adaptor 3/4',4,1),(310,'PVC Pipe  25mm X 3m',4,1),(311,'PVC Pipe 3\" X 3m',4,1),(312,'RSC Pipe 3 \" X 3m',4,1),(313,'Anchor Bolt w/ Nut 20mmX50mm',11,1),(314,'Anchor Bolt w/ Nut 25mmX50mm',11,1),(315,'Anchor Bolt w/ Nut 1.5mtrs',11,1),(316,'Cherry Can',11,1),(317,'Christmas Gift',11,11),(318,'Empty Plastic Blue Drum',11,1);
UNLOCK TABLES;
DROP TABLE IF EXISTS `matinfo`;
CREATE TABLE `matinfo` (
  `matinfo_id` int(11) NOT NULL AUTO_INCREMENT,
  `matinfo_prevStock` int(11) NOT NULL,
  `matinfo_project` int(11) NOT NULL,
  `matinfo_notif` varchar(45) NOT NULL,
  `currentQuantity` varchar(45) NOT NULL,
  `matinfo_matname` int(11) NOT NULL,
  PRIMARY KEY (`matinfo_id`),
  UNIQUE KEY `matinfo_id_UNIQUE` (`matinfo_id`),
  KEY `matname_idx` (`matinfo_matname`),
  KEY `matproject_idx` (`matinfo_project`),
  CONSTRAINT `matname` FOREIGN KEY (`matinfo_matname`) REFERENCES `materials` (`mat_id`) ON UPDATE CASCADE,
  CONSTRAINT `matproject` FOREIGN KEY (`matinfo_project`) REFERENCES `projects` (`projects_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;
LOCK TABLES `matinfo` WRITE;
INSERT INTO `matinfo` VALUES (1,100,1,'50','70',1),(2,300,3,'50','150',1),(3,100,1,'50','75',3),(4,250,1,'50','45',5),(5,28,1,'50','49',7),(6,150,1,'50','75',9),(7,100,1,'50','100',11),(8,72,1,'50','150',13),(9,200,1,'50','25',15),(10,35,1,'20','15',17),(11,80,1,'50','40',19),(12,150,1,'20','50',21),(13,200,1,'50','128',23),(14,180,1,'100','160',25),(15,120,1,'75','50',27),(16,80,1,'50','60',29);
UNLOCK TABLES;
DROP TABLE IF EXISTS `hauling`;
CREATE TABLE `hauling` (
  `hauling_id` int(11) NOT NULL AUTO_INCREMENT,
  `hauling_no` int(11) NOT NULL,
  `hauling_date` date NOT NULL,
  `hauling_deliverTo` varchar(45) NOT NULL,
  `hauling_hauledFrom` varchar(45) NOT NULL,
  `hauling_quantity` int(11) NOT NULL,
  `hauling_unit` int(11) NOT NULL,
  `hauling_matname` int(11) NOT NULL,
  `hauling_hauledBy` varchar(45) NOT NULL,
  `hauling_requestedBy` varchar(45) NOT NULL,
  `hauling_warehouseman` varchar(45) NOT NULL,
  `hauling_approvedBy` varchar(45) NOT NULL,
  `hauling_truckDetailsType` varchar(45) NOT NULL,
  `hauling_truckDetailsPlateNo` varchar(45) NOT NULL,
  `hauling_truckDetailsPO` varchar(45) NOT NULL,
  `hauling_truckDetailsHaulerDR` varchar(45) NOT NULL,
  `hauling_status` varchar(45) NOT NULL,
  `hauling_mateng` int(11) NOT NULL,
  PRIMARY KEY (`hauling_id`),
  UNIQUE KEY `hauling_id_UNIQUE` (`hauling_id`),
  KEY `haulingmatname_idx` (`hauling_matname`),
  KEY `haulingunit_idx` (`hauling_unit`),
  KEY `haulingmateng_idx` (`hauling_mateng`),
  CONSTRAINT `haulingmateng` FOREIGN KEY (`hauling_mateng`) REFERENCES `accounts` (`accounts_id`) ON UPDATE CASCADE,
  CONSTRAINT `haulingmatname` FOREIGN KEY (`hauling_matname`) REFERENCES `materials` (`mat_id`) ON UPDATE CASCADE,
  CONSTRAINT `haulingunit` FOREIGN KEY (`hauling_unit`) REFERENCES `materials` (`mat_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;
LOCK TABLES `hauling` WRITE;
INSERT INTO `hauling` VALUES (1,1,'2019-03-03','Rimando Inc.','NGCB Expansion Site',250,1,1,'Caryl Oficiar','Ray Servidad','Vincent Ibalio','Jam Rocafort','HOWO Dump Truck','QWE 1234','171036','12345','To be returned',1),(2,221,'2019-04-04','Servidad Inc.','SOGO Hotel Baguio',100,1,1,'Vince Tagudar','Theo Rivera','Vincent Ibalio','Jam Rocafort','HOWO Dump Truck','QWE 5687','171725','72341','To be returned',1),(3,122,'2019-05-05','Vinluan Corp.','NGCB Expansion Site',300,2,1,'Vincent Ibalio','Jam Rocafort','Vincent Ibalio','Jam Rocafort','Armored Truck','ASA 1234','123467','58643','Permanently Hauled',1),(4,123,'2019-02-14','Dela Cruz Corp.','SOGO Hotel Dagupan',150,1,1,'Jeron Javierto','Harold Vinluan','Vincent Ibalio','Jam Rocafort','HOWO Dump Truck','CRY 5643','794512','5674','To be returned',1),(5,145,'2019-12-27','Vinluan Corp.','SOGO Hotel Baguio',135,2,1,'Caryl Oficiar','Jeron Javierto','Earl Rimando','Jam Rocafort','HOWO Dump Truck','ALA 6299','542122','51322','Permanently Hauled',1),(6,146,'2019-05-14','Ibalio Corp.','Hotel 164',123,1,1,'Theo Rivera','Genrie Gayaso','Vincent Ibalio','Jam Rocafort','Armored Truck','AMA 8765','211556','515863','To be returned',1),(7,147,'2019-12-12','Tabinas Corp.','Hollywood Inn',132,1,1,'Harold Vinluan','Vince Tagudar','Earl Rimando','Jam Rocafort','HOWO Dump Truck','IAN 6969','696969','51448','Permanently Hauled',1),(8,123,'2018-05-05','Rocafort Corp.','Citylights Hotel',1356,2,1,'Marcus Dela Cruz','Aaron Quitoriano','Vincent Ibalio','Jam Rocafort','HOWO Dump Truck','RAY 6969','565656','51548','Permanently Hauled',1),(9,120,'2015-10-25','Oficiar Corp.','NGCB Expansion Site',765,2,1,'Ray Servidad','Jp Sese','Earl Rimando','Jam Rocafort','Armored Truck','MAC 1234','151515','78762','Permanently Hauled',4),(10,2,'1999-11-25','Cariño Corp.','SOGO Hotel Dagupan',934,1,1,'Harold Vinluan','Ervin Fernandez','Vincent Ibalio','Jam Rocafort','HOWO Dump Truck','AMY 4590','789412','54956','To be returned',6),(11,3,'2020-11-25','Taguinay Corp.','Hollywood Inn',459,1,1,'Harold Vinluan','Javerick Aqui','Earl Rimando','Jam Rocafort','Armored Truck','JEK 6969','002491','51949','Permanently Hauled',12),(12,345,'2019-02-14','Vinluan Corp.','PMA Warehouse',100,1,1,'Benz Servidad','Marcus Dela Cruz','Vincent Ibalio','Jam Rocafort','HOWO Dump Truck','HAR 8686','019212','84512','Permanently Hauled',15),(13,652,'2019-11-25','Servidad Corp. ','Disneyland Baguio',145,1,1,'Vince Tagudar','Jenn Dela Cruz','Earl Rimando','Jam Rocafort','Armored Truck','BEN 2012','354670','7821','To be returned',12),(14,11,'2019-09-21','Tabinas Corp.','SLU Gymnasium',76,2,1,'Jek Rosal','Harold Vinluan','Vincent Ibalio','Jam Rocafort','HOWO Dump Truck','ZEK 1269','343426','54882','To be returned',6),(15,10,'2019-05-30','Vinluan Corp.','SLU Swimming Pool',90,1,1,'Rizalde Velasco','Cong Velasquez','Earl Rimando','Jam Rocafort','HOWO Dump Truck','GFO 5487','343469','51586','Permanently Hauled',4);
UNLOCK TABLES;
DROP TABLE IF EXISTS `lastmatinfo`;
CREATE TABLE `lastmatinfo` (
  `lastmatinfo_id` int(11) NOT NULL AUTO_INCREMENT,
  `lastmatinfo_matname` varchar(45) NOT NULL,
  `lastmatinfo_categ` varchar(45) NOT NULL,
  `lastmatinfo_prevStock` int(11) NOT NULL,
  `lastmatinfo_unit` varchar(45) NOT NULL,
  `lastmatinfo_deliveredMat` int(11) NOT NULL,
  `lastmatinfo_matPulledOut` int(11) NOT NULL,
  `lastmatinfo_accumulatedMat` int(11) NOT NULL,
  `lastmatinfo_matOnSite` int(11) NOT NULL,
  `lastmatinfo_project` varchar(45) NOT NULL,
  `lastmatinfo_year` varchar(45) NOT NULL,
  `lastmatinfo_month` varchar(45) NOT NULL,
  PRIMARY KEY (`lastmatinfo_id`),
  UNIQUE KEY `lastmatinfo_id_UNIQUE` (`lastmatinfo_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
LOCK TABLES `lastmatinfo` WRITE;
UNLOCK TABLES;
DROP TABLE IF EXISTS `logs`;
CREATE TABLE `logs` (
  `logs_id` int(11) NOT NULL AUTO_INCREMENT,
  `logs_datetime` datetime NOT NULL,
  `logs_activity` varchar(45) NOT NULL,
  `logs_logsOf` int(11) NOT NULL,
  PRIMARY KEY (`logs_id`),
  UNIQUE KEY `logs_id_UNIQUE` (`logs_id`),
  KEY `logsmateng_idx` (`logs_logsOf`),
  CONSTRAINT `logsmateng` FOREIGN KEY (`logs_logsOf`) REFERENCES `accounts` (`accounts_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
LOCK TABLES `logs` WRITE;
INSERT INTO `logs` VALUES (1,'2019-04-09 14:53:30','Created Material',1),(2,'2019-03-18 11:27:40','Filled-out Hauling Form',1),(3,'2019-01-25 08:15:23','Filled-out Requisition Slip',14),(4,'2019-05-13 18:49:03','Created Unit',4),(5,'2019-02-24 15:12:29','Filled-out Disposal Slip',6),(6,'2019-06-01 11:18:34','Created Material',12),(7,'2019-05-11 09:22:51','Filled-out Replacement Form',6),(8,'2019-06-02 13:25:39','Created Category',4),(9,'2019-03-28 12:35:10','Created To-do',8),(10,'2019-04-09 14:11:59','Created Unit',10),(11,'2019-05-13 11:41:15','Filled-out Requisition Slip',14);
UNLOCK TABLES;
DROP TABLE IF EXISTS `projmateng`;
CREATE TABLE `projmateng` (
  `projmateng_id` int(11) NOT NULL AUTO_INCREMENT,
  `projmateng_project` int(11) NOT NULL,
  `projmateng_mateng` int(11) NOT NULL,
  PRIMARY KEY (`projmateng_id`),
  UNIQUE KEY `projacc_id_UNIQUE` (`projmateng_id`),
  KEY `projmateng_of_idx` (`projmateng_mateng`),
  KEY `projmateng_proj_idx` (`projmateng_project`),
  CONSTRAINT `projmateng_of` FOREIGN KEY (`projmateng_mateng`) REFERENCES `accounts` (`accounts_id`) ON UPDATE CASCADE,
  CONSTRAINT `projmateng_proj` FOREIGN KEY (`projmateng_project`) REFERENCES `projects` (`projects_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
LOCK TABLES `projmateng` WRITE;
INSERT INTO `projmateng` VALUES (1,1,1),(2,3,1);
UNLOCK TABLES;
DROP TABLE IF EXISTS `request`;
CREATE TABLE `request` (
  `req_id` int(11) NOT NULL AUTO_INCREMENT,
  `req_username` int(11) NOT NULL,
  `req_date` date NOT NULL,
  `req_status` varchar(45) NOT NULL,
  PRIMARY KEY (`req_id`),
  UNIQUE KEY `req_id_UNIQUE` (`req_id`),
  KEY `req_uname_idx` (`req_username`),
  CONSTRAINT `req_uname` FOREIGN KEY (`req_username`) REFERENCES `accounts` (`accounts_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
LOCK TABLES `request` WRITE;
INSERT INTO `request` VALUES (1,1,'2019-04-14','declined'),(2,3,'2019-02-23','accepted'),(3,1,'2019-05-13','pending'),(4,4,'2019-03-13','pending'),(5,7,'2019-02-14','declined'),(6,9,'2019-04-04','acepted'),(7,5,'2019-01-31','pending'),(8,11,'2019-05-13','accepted'),(9,13,'2019-06-01','declined'),(10,14,'2019-04-30','pending'),(11,6,'2019-03-27','accepted');
UNLOCK TABLES;
DROP TABLE IF EXISTS `requisition`;
CREATE TABLE `requisition` (
  `requisition_id` int(11) NOT NULL AUTO_INCREMENT,
  `requisition_no` int(11) NOT NULL,
  `requisition_date` date NOT NULL,
  `requisition_qty` int(11) NOT NULL,
  `requisition_matname` int(11) NOT NULL,
  `requisition_areaOfUsage` varchar(45) NOT NULL,
  `requisition_remarks` varchar(65) NOT NULL,
  `requisition_reqBy` varchar(45) NOT NULL,
  `requisition_approvedBy` varchar(45) NOT NULL,
  PRIMARY KEY (`requisition_id`),
  UNIQUE KEY `requisition_id_UNIQUE` (`requisition_id`),
  KEY `requisitionmatname_idx` (`requisition_matname`),
  CONSTRAINT `requisitionmatname` FOREIGN KEY (`requisition_matname`) REFERENCES `materials` (`mat_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
LOCK TABLES `requisition` WRITE;
INSERT INTO `requisition` VALUES (1,6527,'2019-05-13',15,1,'B-Up','Please','Ray Servidad','Benz Servidad'),(2,6528,'2019-04-25',120,2,'B-Down','For Use','Mark Tabinas','Jam Rocafort'),(3,6529,'2019-06-25',11,3,'Lower Ground','Yooo','Ray Servidad','Jam Rocafort'),(4,6530,'2026-11-25',2,4,'Upper Ground','Ughh','Harold Vinluan','Harold Vinluan'),(5,6531,'2025-11-25',56,5,'Basement','Right','Vincent Ibalio','Jam Rocafort'),(6,6532,'2024-11-25',69,6,'Rooftop','Left','Theo Rivera','Ray Servidad'),(7,6533,'2023-11-25',75,7,'B-Up P69','witwew','Mikka Taguinay','Jam Rocafort'),(8,6534,'2022-11-25',79,8,'P30','awew','Jonelle Cariño','Harold Vinluan'),(9,6535,'2021-11-25',79,9,'A20','Good','Caryl Oficiar','Jam Rocafort'),(10,6536,'2020-11-25',100,10,'S9','Borrow only','Jam Rocafort','Benz Servidad'),(11,1437,'2019-03-03',120,11,'3i','To be returned','Josa Eco Cruz','Josa Eco Cruz');
UNLOCK TABLES;
DROP TABLE IF EXISTS `returns`;
CREATE TABLE `returns` (
  `returns_id` int(11) NOT NULL AUTO_INCREMENT,
  `returns_matname` int(11) NOT NULL,
  `returns_returnedqty` int(11) NOT NULL,
  `returns_date` date NOT NULL,
  `returns_status` varchar(45) NOT NULL,
  `returns_returningqty` int(11) NOT NULL,
  PRIMARY KEY (`returns_id`),
  UNIQUE KEY `returns_id_UNIQUE` (`returns_id`),
  KEY `returnsmatname_idx` (`returns_matname`),
  CONSTRAINT `returnshauling` FOREIGN KEY (`returns_id`) REFERENCES `hauling` (`hauling_id`) ON UPDATE CASCADE,
  CONSTRAINT `returnsmatname` FOREIGN KEY (`returns_matname`) REFERENCES `hauling` (`hauling_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;
LOCK TABLES `returns` WRITE;
INSERT INTO `returns` VALUES (1,1,20,'2019-04-13','Incomplete',15),(2,2,50,'2019-03-18','Complete',50),(3,3,39,'2019-05-13','Incomplete',30),(4,4,60,'2019-06-02','Complete',60),(5,5,35,'2019-05-28','Incomplete',29),(6,6,100,'2019-02-12','Complete',100),(7,7,45,'2019-04-11','Incomplete',30),(8,8,80,'2019-02-02','Complete',80),(9,9,120,'2019-04-19','Incomplete',100),(10,10,40,'2019-01-30','Complete',40),(11,11,95,'2019-05-05','Incomplete',80),(12,12,70,'2019-02-14','Complete',61),(13,13,60,'2019-11-25','Incomplete',20),(14,14,12,'2019-09-21','Complete',5),(15,15,1,'2019-05-30','Complete',1);
UNLOCK TABLES;
DROP TABLE IF EXISTS `todo`;
CREATE TABLE `todo` (
  `todo_id` int(11) NOT NULL AUTO_INCREMENT,
  `todo_date` date NOT NULL,
  `todo_task` varchar(45) NOT NULL,
  `todo_status` varchar(45) NOT NULL,
  `todoOf` int(11) NOT NULL,
  PRIMARY KEY (`todo_id`),
  UNIQUE KEY `todo_id_UNIQUE` (`todo_id`),
  KEY `todo_of_idx` (`todoOf`),
  CONSTRAINT `todo_of` FOREIGN KEY (`todoOf`) REFERENCES `accounts` (`accounts_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
LOCK TABLES `todo` WRITE;
INSERT INTO `todo` VALUES (1,'2019-05-24','Delivery Day','done',1),(2,'2019-05-31','Hauling','in progress',1),(3,'2019-02-28','Submit Report','done',1),(4,'2019-01-11','Delivery','done',1),(5,'2019-05-31','Submit Report','in progress',1),(6,'2019-06-02','Delivery for the month of June','in progress',1),(7,'2019-04-11','Pull Out Beam Hanger','done',1),(8,'2019-03-23','Haul Items','done',1),(9,'2019-06-04','Pull Out Items','in progress',1),(10,'2019-06-30','Submit Monthly Report','in progress',1),(11,'2019-04-04','Delivery','done',1);
UNLOCK TABLES;
DROP TABLE IF EXISTS `usagein`;
CREATE TABLE `usagein` (
  `usagein_id` int(11) NOT NULL AUTO_INCREMENT,
  `usagein_date` date NOT NULL,
  `usagein_quantity` varchar(45) NOT NULL,
  `usagein_unit` int(11) NOT NULL,
  `pulledOutBy` varchar(45) NOT NULL,
  `usagein_areaOfUsage` varchar(45) NOT NULL,
  `usagein_matname` int(11) NOT NULL,
  `usagein_project` int(11) NOT NULL,
  PRIMARY KEY (`usagein_id`),
  UNIQUE KEY `usagein_id_UNIQUE` (`usagein_id`),
  KEY `usageunit_idx` (`usagein_unit`),
  KEY `usagematname_idx` (`usagein_matname`),
  KEY `usageproject_idx` (`usagein_project`),
  CONSTRAINT `usagematname` FOREIGN KEY (`usagein_matname`) REFERENCES `materials` (`mat_id`) ON UPDATE CASCADE,
  CONSTRAINT `usageunit` FOREIGN KEY (`usagein_unit`) REFERENCES `materials` (`mat_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
LOCK TABLES `usagein` WRITE;
INSERT INTO `usagein` VALUES (1,'2019-03-21','3',1,'Laroza','SM B-up',1,0),(2,'2019-03-03','34',1,'Dulce','PH-2',1,0),(3,'2019-03-05','45',1,'Bisaya','PH-2 B-3',1,0),(4,'2019-03-08','17',2,'Vinaya','Foot',1,0),(5,'2019-03-07','59',1,'Pepito','B-up',1,0),(6,'2019-03-06','69',1,'Pepito','PH-1 B-up',1,0);
UNLOCK TABLES;
DROP TABLE IF EXISTS `deliveredin`;
CREATE TABLE `deliveredin` (
  `deliveredin_id` int(11) NOT NULL AUTO_INCREMENT,
  `deliveredin_date` date NOT NULL,
  `deliveredin_quantity` varchar(45) NOT NULL,
  `deliveredin_unit` int(11) NOT NULL,
  `suppliedBy` varchar(45) NOT NULL,
  `deliveredin_matname` int(11) NOT NULL,
  `deliveredin_from` varchar(45) NOT NULL,
  PRIMARY KEY (`deliveredin_id`),
  UNIQUE KEY `deliveredin_id_UNIQUE` (`deliveredin_id`),
  KEY `deliv_matname_idx` (`deliveredin_matname`),
  KEY `deliveredunit_idx` (`deliveredin_unit`),
  CONSTRAINT `deliveredmatname` FOREIGN KEY (`deliveredin_matname`) REFERENCES `materials` (`mat_id`) ON UPDATE CASCADE,
  CONSTRAINT `deliveredunit` FOREIGN KEY (`deliveredin_unit`) REFERENCES `materials` (`mat_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
LOCK TABLES `deliveredin` WRITE;
INSERT INTO `deliveredin` VALUES (1,'2019-08-11','350',1,'Rimando Corp.',1,'Main Office'),(2,'2019-06-12','69',2,'Servidad Corp.',2,'Petty Cash'),(3,'2019-05-25','95',1,'LeBron Corp.',1,'Main Office'),(4,'2019-04-28','100',1,'Rimando Corp.',1,'Petty Cash');
UNLOCK TABLES;
DROP TABLE IF EXISTS `disposal`;
CREATE TABLE `disposal` (
  `disposal_id` int(11) NOT NULL AUTO_INCREMENT,
  `disposal_date` date NOT NULL,
  `disposal_qty` int(11) NOT NULL,
  `disposal_matname` int(11) NOT NULL,
  `disposal_remarks` varchar(65) NOT NULL,
  PRIMARY KEY (`disposal_id`),
  UNIQUE KEY `disposal_id_UNIQUE` (`disposal_id`),
  KEY `disposalmatname_idx` (`disposal_matname`),
  CONSTRAINT `disposalmatname` FOREIGN KEY (`disposal_matname`) REFERENCES `materials` (`mat_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;
LOCK TABLES `disposal` WRITE;
INSERT INTO `disposal` VALUES (1,'2019-07-23',400,1,'Broken '),(2,'2019-06-11',20,2,'Disabled Nut'),(3,'2019-02-28',18,5,'Loose'),(4,'2019-02-16',35,3,'Broken'),(5,'2019-04-21',10,4,'Broken'),(6,'2019-03-22',25,5,'Poured'),(7,'2019-05-13',50,6,'Broken'),(8,'2019-04-28',75,7,'Rusty'),(9,'2019-06-02',25,8,'Loose'),(10,'2019-01-31',65,9,'Rusty'),(11,'2019-02-28',80,10,'Broken'),(12,'2019-07-11',10,1,'Disabled nut'),(13,'2019-08-25',56,1,'Rusty'),(14,'2019-11-25',75,2,'Loose'),(15,'2019-12-26',81,3,'Broken');
UNLOCK TABLES;
DROP TABLE IF EXISTS `returnhistory`;
CREATE TABLE `returnhistory` (
  `returnHistory_id` int(11) NOT NULL AUTO_INCREMENT,
  `returnHistory_material` int(11) NOT NULL,
  PRIMARY KEY (`returnHistory_id`),
  UNIQUE KEY `returnHistory_id_UNIQUE` (`returnHistory_id`),
  KEY `returnhistoryMatname_idx` (`returnHistory_material`),
  CONSTRAINT `returnhistoryMatname` FOREIGN KEY (`returnHistory_material`) REFERENCES `returns` (`returns_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
LOCK TABLES `returnhistory` WRITE;
UNLOCK TABLES;