DROP TABLE IF EXISTS `accounts`;
CREATE TABLE `accounts` (
  `accounts_id` int(11) NOT NULL AUTO_INCREMENT,
  `accounts_fname` varchar(45) NOT NULL,
  `accounts_lname` varchar(45) NOT NULL,
  `accounts_username` varchar(45) NOT NULL,
  `accounts_password` varchar(150) NOT NULL,
  `accounts_type` varchar(45) NOT NULL,
  `accounts_email` varchar(45) NOT NULL,
  `accounts_deletable` varchar(45) NOT NULL,
  `accounts_status` varchar(45) NOT NULL,
  PRIMARY KEY (`accounts_id`),
  UNIQUE KEY `accounts_id_UNIQUE` (`accounts_id`),
  UNIQUE KEY `accounts_username_UNIQUE` (`accounts_username`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;
LOCK TABLES `accounts` WRITE;
INSERT INTO `accounts` VALUES (1,'materials','engineer','materials_engineer','$2y$10$9KWB6zo6BUhC2U9qWyIkJuwfLMDK6GnoctpYbaxCpT4IuBYHyUjZy','Materials Engineer','mateng@gmail.com','no','active'),(2,'admin','admin','admin','$2y$10$7MiO1behDuzQBbUdNL1riOjO7eDnOIcbL2J4DWIvec/cRMCZduRCm','Admin','admin@gmail.com','no','active'),(3,'View','Only','view_only','$2y$10$xkl8OZp95hIZNkSUfKul5.wYUVZvNDJK12PdMrhmO285A8ogM6/c2','View Only','viewonly@gmail.com','no','active'),(4,'Ray Oliver','Servidad','r_servidad','benzservidad','Materials Engineer','rservidad@gmail.com','yes','active'),(5,'Jonelle','Carino','jonellec2','carinojonelle','View Only','jonellecarino12@gmail.com','yes','active'),(6,'Caryl Marie','Oficiar','cmsoficiar','carylmarie12','Materials Engineer','mariecaryl19@gmail.com','yes','active'),(7,'Jam Spica','Rocafort','jamspicaa20','jamspicarocafort','View Only','jspica25@gmail.com','yes','active'),(8,'Theo Michael Kenneth','Rivera','trivera','theorivera','Materials Engineer','tmkrivera@gmail.com','yes','inactive'),(9,'Mikka','Tuguinay','tuguinaymikka12','mikkatuguinay123','View Only','mikkatuguinay@gmail.com','yes','inactive'),(10,'Harold Angelo','Vinluan','har_vinluan','family2010','Materials Engineer','haroldangelo@gmail.com','yes','inactive'),(11,'Vincent','Ibalio','ibaliov','kobeparas','View Only','vincentibalio13@gmail.com','yes','inactive'),(12,'Wanda','Maximoff','wandamax08','visionislove69','Materials Engineer','wmaximoff@gmail.com','yes','active'),(13,'Tony','Stark','starktony','pepperforever08','View Only','iamironman@gmail.com','yes','inactive'),(14,'Gal','Gadot','gadotgal13','crushkosibenzlovelove','Materials Engineer','ggadot13@gmail.com','yes','active'),(15,'Mark','Tabinas','madtabinas','limangsegundo','View Only','mtabinas@gmail.com','yes','inactive');
UNLOCK TABLES;
DROP TABLE IF EXISTS `projects`;
CREATE TABLE `projects` (
  `projects_id` int(11) NOT NULL AUTO_INCREMENT,
  `projects_name` varchar(45) NOT NULL,
  `projects_address` varchar(50) NOT NULL,
  `projects_sdate` date NOT NULL,
  `projects_edate` date NOT NULL,
  `projects_status` varchar(45) NOT NULL,
  PRIMARY KEY (`projects_id`),
  UNIQUE KEY `projects_id_UNIQUE` (`projects_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;
LOCK TABLES `projects` WRITE;
INSERT INTO `projects` VALUES (1,'SM Baguio Expansion','Luneta Hill, Baguio City','2017-03-17','2019-03-17','open'),(2,'SOGO Hotel Baguio','Bakakeng, Baguio City','2018-05-13','2020-05-13','closed'),(3,'Hyatt Hotel Baguio','Engineers Hill, Baguio City','2015-08-11','2018-08-11','open'),(4,'SOGO Hotel Dagupan','Bonuan Gueset, Dagupan City','2019-05-05','2019-10-05','open'),(5,'Skyranch Baguio','Luneta Hill, Baguio City','2018-01-03','2019-11-25','open'),(6,'SM Dagupan','Mayombo St., Dagupan City','2018-12-27','2019-12-27','open'),(7,'PMA Warehouse','Loakan Road, Baguio City','2020-04-12','2021-01-01','open'),(8,'S&R Baguio ','Bakakeng Rd., Baguio City','2019-05-05','2019-07-11','open'),(9,'Disneyland Baguio','La Trinidad, Baguio City','2011-02-14','2015-02-14','closed'),(10,'7 Wonders Waterpark','Bonuan Binloc, Dagupan City','2012-07-08','2013-06-21','closed'),(11,'SLU Gymnasium','Bonifacio St., Baguio City','2015-03-25','2014-05-05','closed'),(12,'SLU Swimming Pool','Bakakeng Rd., Baguio City','2019-01-25','2019-08-08','open');
UNLOCK TABLES;
DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `categories_id` int(11) NOT NULL AUTO_INCREMENT,
  `categories_name` varchar(45) NOT NULL,
  PRIMARY KEY (`categories_id`),
  UNIQUE KEY `categories_id_UNIQUE` (`categories_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
LOCK TABLES `categories` WRITE;
INSERT INTO `categories` VALUES (1,'Blades'),(2,'Formworks'),(3,'Electrical'),(4,'Plumbing'),(5,'Lubricants'),(6,'Table Forms'),(7,'Office'),(8,'Tower Crane'),(9,'Consumables'),(10,'Heavy Equipment'),(11,'Others');
UNLOCK TABLES;
DROP TABLE IF EXISTS `catproj`;
CREATE TABLE `catproj` (
  `catproj_project` int(11) NOT NULL,
  `catproj_categories` int(11) NOT NULL,
  KEY `catproj_proj_idx` (`catproj_project`),
  KEY `catproj_categ_idx` (`catproj_categories`),
  CONSTRAINT `catproj_categ` FOREIGN KEY (`catproj_categories`) REFERENCES `categories` (`categories_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `catproj_proj` FOREIGN KEY (`catproj_project`) REFERENCES `projects` (`projects_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
LOCK TABLES `catproj` WRITE;
UNLOCK TABLES;
DROP TABLE IF EXISTS `unit`;
CREATE TABLE `unit` (
  `unit_id` int(11) NOT NULL AUTO_INCREMENT,
  `unit_name` varchar(45) NOT NULL,
  PRIMARY KEY (`unit_id`),
  UNIQUE KEY `unit_id_UNIQUE` (`unit_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;
LOCK TABLES `unit` WRITE;
INSERT INTO `unit` VALUES (1,'pcs'),(2,'mtrs'),(3,'rolls'),(4,'set'),(5,'pairs'),(6,'sec'),(7,'pails'),(8,'units'),(9,'bags'),(10,'kg');
UNLOCK TABLES;
DROP TABLE IF EXISTS `materials`;
CREATE TABLE `materials` (
  `mat_id` int(11) NOT NULL AUTO_INCREMENT,
  `mat_name` varchar(65) NOT NULL,
  `mat_categ` int(11) NOT NULL,
  `mat_unit` int(11) NOT NULL,
  PRIMARY KEY (`mat_id`),
  UNIQUE KEY `mat_id_UNIQUE` (`mat_id`),
  UNIQUE KEY `mat_name_UNIQUE` (`mat_name`),
  KEY `matcateg_idx` (`mat_categ`),
  KEY `matunit_idx` (`mat_unit`),
  CONSTRAINT `matcateg` FOREIGN KEY (`mat_categ`) REFERENCES `categories` (`categories_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `matunit` FOREIGN KEY (`mat_unit`) REFERENCES `unit` (`unit_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=latin1;
LOCK TABLES `materials` WRITE;
INSERT INTO `materials` VALUES (1,'A-Clamp Assymbly',1,1),(2,'Bolt & Nut 1/2x4 w/ washer',1,1),(3,'Grounding Wire 60mmsg',2,2),(4,'THHN Wire 3.5mm2',2,3),(5,'Bushing 3\"',3,1),(6,'PVC Pipe 3\" x 3m',3,1),(7,'Cup Brush 4\"',4,1),(8,'Cutting Disc 4\"',4,1),(9,'Beam Hanger',6,1),(10,'Table Form T1 (3.353 x 6.990)',6,1),(11,'Christmas Gift',11,1),(12,'Anchor Bolt w/ Nut 20mm x 50mm',11,1),(13,'Panel Cup',2,1),(14,'Panel Cup (NEW)',2,1),(15,'Connecting Bridge',6,1),(16,'Triangular Posts 6m',6,1),(17,'Table Forms(3.353 x 4.401)',6,4),(18,'Hard Hat (White)',7,1),(19,'Rain Boots',7,5),(20,'Adaptor',8,6),(21,'Boom',8,6),(22,'Mast Bolt',8,1),(23,'Grinding Disc 7\"',1,1),(24,'Gear Oil',5,7),(25,'ATF',5,7),(26,'Exhaust Fan',10,8),(27,'Dump Box',10,8),(28,'Fuel Filter',10,1),(29,'Metal Strip',9,1),(30,'Nylon Rope',9,3),(31,'Tile Adhesive',9,9),(32,'Welding Rod 7018',9,10);
UNLOCK TABLES;
DROP TABLE IF EXISTS `matinfo`;
CREATE TABLE `matinfo` (
  `matinfo_id` int(11) NOT NULL AUTO_INCREMENT,
  `matinfo_prevStock` int(11) NOT NULL,
  `matinfo_project` int(11) NOT NULL,
  `matinfo_notif` varchar(45) NOT NULL,
  `currentQuantity` varchar(45) NOT NULL,
  `matinfo_matname` int(11) NOT NULL,
  PRIMARY KEY (`matinfo_id`),
  UNIQUE KEY `matinfo_id_UNIQUE` (`matinfo_id`),
  KEY `matname_idx` (`matinfo_matname`),
  KEY `matproject_idx` (`matinfo_project`),
  CONSTRAINT `matname` FOREIGN KEY (`matinfo_matname`) REFERENCES `materials` (`mat_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `matproject` FOREIGN KEY (`matinfo_project`) REFERENCES `projects` (`projects_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
LOCK TABLES `matinfo` WRITE;
INSERT INTO `matinfo` VALUES (1,100,1,'50','70',1),(2,300,3,'50','150',1),(3,100,1,'50','75',3),(4,250,1,'50','45',5),(5,28,1,'50','49',7),(6,150,1,'50','75',9),(7,100,1,'50','100',11),(8,72,1,'50','150',13),(9,200,1,'50','25',15),(10,35,1,'20','15',17),(11,80,1,'50','40',19),(12,150,1,'20','50',21),(13,200,1,'50','128',23),(14,180,1,'100','160',25),(15,120,1,'75','50',27),(16,80,1,'50','60',29);
UNLOCK TABLES;
DROP TABLE IF EXISTS `hauling`;
CREATE TABLE `hauling` (
  `hauling_id` int(11) NOT NULL AUTO_INCREMENT,
  `hauling_no` int(11) NOT NULL,
  `hauling_date` date NOT NULL,
  `hauling_deliverTo` varchar(45) NOT NULL,
  `hauling_hauledFrom` varchar(45) NOT NULL,
  `hauling_quantity` int(11) NOT NULL,
  `hauling_unit` int(11) NOT NULL,
  `hauling_matname` int(11) NOT NULL,
  `hauling_hauledBy` varchar(45) NOT NULL,
  `hauling_requestedBy` varchar(45) NOT NULL,
  `hauling_warehouseman` varchar(45) NOT NULL,
  `hauling_approvedBy` varchar(45) NOT NULL,
  `hauling_truckDetailsType` varchar(45) NOT NULL,
  `hauling_truckDetailsPlateNo` varchar(45) NOT NULL,
  `hauling_truckDetailsPO` varchar(45) NOT NULL,
  `hauling_truckDetailsHaulerDR` varchar(45) NOT NULL,
  `hauling_status` varchar(45) NOT NULL,
  `hauling_mateng` int(11) NOT NULL,
  PRIMARY KEY (`hauling_id`),
  UNIQUE KEY `hauling_id_UNIQUE` (`hauling_id`),
  KEY `haulingmatname_idx` (`hauling_matname`),
  KEY `haulingunit_idx` (`hauling_unit`),
  KEY `haulingmateng_idx` (`hauling_mateng`),
  CONSTRAINT `haulingmateng` FOREIGN KEY (`hauling_mateng`) REFERENCES `accounts` (`accounts_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `haulingmatname` FOREIGN KEY (`hauling_matname`) REFERENCES `materials` (`mat_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `haulingunit` FOREIGN KEY (`hauling_unit`) REFERENCES `unit` (`unit_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;
LOCK TABLES `hauling` WRITE;
INSERT INTO `hauling` VALUES (1,1,'2019-03-03','Rimando Inc.','NGCB Expansion Site',250,1,1,'Caryl Oficiar','Ray Servidad','Vincent Ibalio','Jam Rocafort','HOWO Dump Truck','QWE 1234','171036','12345','To be returned',1),(2,221,'2019-04-04','Servidad Inc.','SOGO Hotel Baguio',100,1,1,'Vince Tagudar','Theo Rivera','Vincent Ibalio','Jam Rocafort','HOWO Dump Truck','QWE 5687','171725','72341','To be returned',1),(3,122,'2019-05-05','Vinluan Corp.','NGCB Expansion Site',300,2,1,'Vincent Ibalio','Jam Rocafort','Vincent Ibalio','Jam Rocafort','Armored Truck','ASA 1234','123467','58643','Permanently Hauled',1),(4,123,'2019-02-14','Dela Cruz Corp.','SOGO Hotel Dagupan',150,1,1,'Jeron Javierto','Harold Vinluan','Vincent Ibalio','Jam Rocafort','HOWO Dump Truck','CRY 5643','794512','5674','To be returned',1),(5,145,'2019-12-27','Vinluan Corp.','SOGO Hotel Baguio',135,2,1,'Caryl Oficiar','Jeron Javierto','Earl Rimando','Jam Rocafort','HOWO Dump Truck','ALA 6299','542122','51322','Permanently Hauled',1),(6,146,'2019-05-14','Ibalio Corp.','Hotel 164',123,1,1,'Theo Rivera','Genrie Gayaso','Vincent Ibalio','Jam Rocafort','Armored Truck','AMA 8765','211556','515863','To be returned',1),(7,147,'2019-12-12','Tabinas Corp.','Hollywood Inn',132,1,1,'Harold Vinluan','Vince Tagudar','Earl Rimando','Jam Rocafort','HOWO Dump Truck','IAN 6969','696969','51448','Permanently Hauled',1),(8,123,'2018-05-05','Rocafort Corp.','Citylights Hotel',1356,2,1,'Marcus Dela Cruz','Aaron Quitoriano','Vincent Ibalio','Jam Rocafort','HOWO Dump Truck','RAY 6969','565656','51548','Permanently Hauled',1),(9,120,'2015-10-25','Oficiar Corp.','NGCB Expansion Site',765,2,1,'Ray Servidad','Jp Sese','Earl Rimando','Jam Rocafort','Armored Truck','MAC 1234','151515','78762','Permanently Hauled',4),(10,2,'1999-11-25','Cariño Corp.','SOGO Hotel Dagupan',934,1,1,'Harold Vinluan','Ervin Fernandez','Vincent Ibalio','Jam Rocafort','HOWO Dump Truck','AMY 4590','789412','54956','To be returned',6),(11,3,'2020-11-25','Taguinay Corp.','Hollywood Inn',459,1,1,'Harold Vinluan','Javerick Aqui','Earl Rimando','Jam Rocafort','Armored Truck','JEK 6969','002491','51949','Permanently Hauled',12),(12,345,'2019-02-14','Vinluan Corp.','PMA Warehouse',100,1,1,'Benz Servidad','Marcus Dela Cruz','Vincent Ibalio','Jam Rocafort','HOWO Dump Truck','HAR 8686','019212','84512','Permanently Hauled',15),(13,652,'2019-11-25','Servidad Corp. ','Disneyland Baguio',145,1,1,'Vince Tagudar','Jenn Dela Cruz','Earl Rimando','Jam Rocafort','Armored Truck','BEN 2012','354670','7821','To be returned',12),(14,11,'2019-09-21','Tabinas Corp.','SLU Gymnasium',76,2,1,'Jek Rosal','Harold Vinluan','Vincent Ibalio','Jam Rocafort','HOWO Dump Truck','ZEK 1269','343426','54882','To be returned',6),(15,10,'2019-05-30','Vinluan Corp.','SLU Swimming Pool',90,1,1,'Rizalde Velasco','Cong Velasquez','Earl Rimando','Jam Rocafort','HOWO Dump Truck','GFO 5487','343469','51586','Permanently Hauled',4);
UNLOCK TABLES;
DROP TABLE IF EXISTS `lastmatinfo`;
CREATE TABLE `lastmatinfo` (
  `lastmatinfo_id` int(11) NOT NULL AUTO_INCREMENT,
  `lastmatinfo_matname` varchar(45) NOT NULL,
  `lastmatinfo_categ` varchar(45) NOT NULL,
  `lastmatinfo_prevStock` int(11) NOT NULL,
  `lastmatinfo_unit` varchar(45) NOT NULL,
  `lastmatinfo_deliveredMat` int(11) NOT NULL,
  `lastmatinfo_matPulledOut` int(11) NOT NULL,
  `lastmatinfo_accumulatedMat` int(11) NOT NULL,
  `lastmatinfo_matOnSite` int(11) NOT NULL,
  `lastmatinfo_project` varchar(45) NOT NULL,
  `lastmatinfo_year` date NOT NULL,
  `lastmatinfo_month` date NOT NULL,
  PRIMARY KEY (`lastmatinfo_id`),
  UNIQUE KEY `lastmatinfo_id_UNIQUE` (`lastmatinfo_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
LOCK TABLES `lastmatinfo` WRITE;
UNLOCK TABLES;
DROP TABLE IF EXISTS `logs`;
CREATE TABLE `logs` (
  `logs_id` int(11) NOT NULL AUTO_INCREMENT,
  `logs_datetime` datetime NOT NULL,
  `logs_activity` varchar(45) NOT NULL,
  `logs_logsOf` int(11) NOT NULL,
  PRIMARY KEY (`logs_id`),
  UNIQUE KEY `logs_id_UNIQUE` (`logs_id`),
  KEY `logsmateng_idx` (`logs_logsOf`),
  CONSTRAINT `logsmateng` FOREIGN KEY (`logs_logsOf`) REFERENCES `accounts` (`accounts_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
LOCK TABLES `logs` WRITE;
INSERT INTO `logs` VALUES (1,'2019-04-09 14:53:30','Created Material',1),(2,'2019-03-18 11:27:40','Filled-out Hauling Form',1),(3,'2019-01-25 08:15:23','Filled-out Requisition Slip',14),(4,'2019-05-13 18:49:03','Created Unit',4),(5,'2019-02-24 15:12:29','Filled-out Disposal Slip',6),(6,'2019-06-01 11:18:34','Created Material',12),(7,'2019-05-11 09:22:51','Filled-out Replacement Form',6),(8,'2019-06-02 13:25:39','Created Category',4),(9,'2019-03-28 12:35:10','Created To-do',8),(10,'2019-04-09 14:11:59','Created Unit',10),(11,'2019-05-13 11:41:15','Filled-out Requisition Slip',14);
UNLOCK TABLES;
DROP TABLE IF EXISTS `projmateng`;
CREATE TABLE `projmateng` (
  `projmateng_id` int(11) NOT NULL AUTO_INCREMENT,
  `projmateng_project` int(11) NOT NULL,
  `projmateng_mateng` int(11) NOT NULL,
  PRIMARY KEY (`projmateng_id`),
  UNIQUE KEY `projacc_id_UNIQUE` (`projmateng_id`),
  KEY `projmateng_of_idx` (`projmateng_mateng`),
  KEY `projmateng_proj_idx` (`projmateng_project`),
  CONSTRAINT `projmateng_of` FOREIGN KEY (`projmateng_mateng`) REFERENCES `accounts` (`accounts_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `projmateng_proj` FOREIGN KEY (`projmateng_project`) REFERENCES `projects` (`projects_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
LOCK TABLES `projmateng` WRITE;
INSERT INTO `projmateng` VALUES (1,1,1),(2,3,1);
UNLOCK TABLES;
DROP TABLE IF EXISTS `request`;
CREATE TABLE `request` (
  `req_id` int(11) NOT NULL AUTO_INCREMENT,
  `req_username` int(11) NOT NULL,
  `req_date` date NOT NULL,
  `req_status` varchar(45) NOT NULL,
  PRIMARY KEY (`req_id`),
  UNIQUE KEY `req_id_UNIQUE` (`req_id`),
  KEY `req_uname_idx` (`req_username`),
  CONSTRAINT `req_uname` FOREIGN KEY (`req_username`) REFERENCES `accounts` (`accounts_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
LOCK TABLES `request` WRITE;
INSERT INTO `request` VALUES (1,1,'2019-04-14','declined'),(2,3,'2019-02-23','accepted'),(3,1,'2019-05-13','pending'),(4,4,'2019-03-13','pending'),(5,7,'2019-02-14','declined'),(6,9,'2019-04-04','acepted'),(7,5,'2019-01-31','pending'),(8,11,'2019-05-13','accepted'),(9,13,'2019-06-01','declined'),(10,14,'2019-04-30','pending'),(11,6,'2019-03-27','accepted');
UNLOCK TABLES;
DROP TABLE IF EXISTS `requisition`;
CREATE TABLE `requisition` (
  `requisition_id` int(11) NOT NULL AUTO_INCREMENT,
  `requisition_no` int(11) NOT NULL,
  `requisition_date` date NOT NULL,
  `requisition_qty` int(11) NOT NULL,
  `requisition_matname` int(11) NOT NULL,
  `requisition_areaOfUsage` varchar(45) NOT NULL,
  `requisition_remarks` varchar(65) NOT NULL,
  `requisition_reqBy` varchar(45) NOT NULL,
  `requisition_approvedBy` varchar(45) NOT NULL,
  PRIMARY KEY (`requisition_id`),
  UNIQUE KEY `requisition_id_UNIQUE` (`requisition_id`),
  KEY `requisitionmatname_idx` (`requisition_matname`),
  CONSTRAINT `requisitionmatname` FOREIGN KEY (`requisition_matname`) REFERENCES `materials` (`mat_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
LOCK TABLES `requisition` WRITE;
INSERT INTO `requisition` VALUES (1,6527,'2019-05-13',15,1,'B-Up','Please','Ray Servidad','Benz Servidad'),(2,6528,'2019-04-25',120,2,'B-Down','For Use','Mark Tabinas','Jam Rocafort'),(3,6529,'2019-06-25',11,3,'Lower Ground','Yooo','Ray Servidad','Jam Rocafort'),(4,6530,'2026-11-25',2,4,'Upper Ground','Ughh','Harold Vinluan','Harold Vinluan'),(5,6531,'2025-11-25',56,5,'Basement','Right','Vincent Ibalio','Jam Rocafort'),(6,6532,'2024-11-25',69,6,'Rooftop','Left','Theo Rivera','Ray Servidad'),(7,6533,'2023-11-25',75,7,'B-Up P69','witwew','Mikka Taguinay','Jam Rocafort'),(8,6534,'2022-11-25',79,8,'P30','awew','Jonelle Cariño','Harold Vinluan'),(9,6535,'2021-11-25',79,9,'A20','Good','Caryl Oficiar','Jam Rocafort'),(10,6536,'2020-11-25',100,10,'S9','Borrow only','Jam Rocafort','Benz Servidad'),(11,1437,'2019-03-03',120,11,'3i','To be returned','Josa Eco Cruz','Josa Eco Cruz');
UNLOCK TABLES;
DROP TABLE IF EXISTS `todo`;
CREATE TABLE `todo` (
  `todo_id` int(11) NOT NULL AUTO_INCREMENT,
  `todo_date` date NOT NULL,
  `todo_task` varchar(45) NOT NULL,
  `todo_status` varchar(45) NOT NULL,
  `todoOf` int(11) NOT NULL,
  PRIMARY KEY (`todo_id`),
  UNIQUE KEY `todo_id_UNIQUE` (`todo_id`),
  KEY `todo_of_idx` (`todoOf`),
  CONSTRAINT `todo_of` FOREIGN KEY (`todoOf`) REFERENCES `accounts` (`accounts_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
LOCK TABLES `todo` WRITE;
INSERT INTO `todo` VALUES (1,'2019-05-24','Delivery Day','done',1),(2,'2019-05-31','Hauling','in progress',1),(3,'2019-02-28','Submit Report','done',1),(4,'2019-01-11','Delivery','done',1),(5,'2019-05-31','Submit Report','in progress',1),(6,'2019-06-02','Delivery for the month of June','in progress',1),(7,'2019-04-11','Pull Out Beam Hanger','done',1),(8,'2019-03-23','Haul Items','done',1),(9,'2019-06-04','Pull Out Items','in progress',1),(10,'2019-06-30','Submit Monthly Report','in progress',1),(11,'2019-04-04','Delivery','done',1);
UNLOCK TABLES;
DROP TABLE IF EXISTS `usagein`;
CREATE TABLE `usagein` (
  `usagein_id` int(11) NOT NULL AUTO_INCREMENT,
  `usagein_date` date NOT NULL,
  `usagein_quantity` varchar(45) NOT NULL,
  `usagein_unit` int(11) NOT NULL,
  `pulledOutBy` varchar(45) NOT NULL,
  `usagein_areaOfUsage` varchar(45) NOT NULL,
  `usagein_matname` int(11) NOT NULL,
  `usagein_project` int(11) NOT NULL,
  PRIMARY KEY (`usagein_id`),
  UNIQUE KEY `usagein_id_UNIQUE` (`usagein_id`),
  KEY `usageunit_idx` (`usagein_unit`),
  KEY `usagematname_idx` (`usagein_matname`),
  KEY `usageproject_idx` (`usagein_project`),
  CONSTRAINT `usagematname` FOREIGN KEY (`usagein_matname`) REFERENCES `materials` (`mat_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `usageunit` FOREIGN KEY (`usagein_unit`) REFERENCES `unit` (`unit_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
LOCK TABLES `usagein` WRITE;
INSERT INTO `usagein` VALUES (1,'2019-03-21','3',1,'Laroza','SM B-up',1,0),(2,'2019-03-03','34',1,'Dulce','PH-2',1,0),(3,'2019-03-05','45',1,'Bisaya','PH-2 B-3',1,0),(4,'2019-03-08','17',2,'Vinaya','Foot',1,0),(5,'2019-03-07','59',1,'Pepito','B-up',1,0),(6,'2019-03-06','69',1,'Pepito','PH-1 B-up',1,0);
UNLOCK TABLES;
DROP TABLE IF EXISTS `deliveredin`;
CREATE TABLE `deliveredin` (
  `deliveredin_id` int(11) NOT NULL AUTO_INCREMENT,
  `deliveredin_date` date NOT NULL,
  `deliveredin_quantity` varchar(45) NOT NULL,
  `deliveredin_unit` int(11) NOT NULL,
  `suppliedBy` varchar(45) NOT NULL,
  `deliveredin_matname` int(11) NOT NULL,
  `deliveredin_from` varchar(45) NOT NULL,
  PRIMARY KEY (`deliveredin_id`),
  UNIQUE KEY `deliveredin_id_UNIQUE` (`deliveredin_id`),
  KEY `deliv_matname_idx` (`deliveredin_matname`),
  KEY `deliv_unit_idx` (`deliveredin_unit`),
  CONSTRAINT `deliveredmatname` FOREIGN KEY (`deliveredin_matname`) REFERENCES `materials` (`mat_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `deliveredunit` FOREIGN KEY (`deliveredin_unit`) REFERENCES `unit` (`unit_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
LOCK TABLES `deliveredin` WRITE;
INSERT INTO `deliveredin` VALUES (1,'2019-08-11','350',1,'Rimando Corp.',1,'Main Office'),(2,'2019-06-12','69',2,'Servidad Corp.',2,'Petty Cash'),(3,'2019-05-25','95',1,'LeBron Corp.',1,'Main Office'),(4,'2019-04-28','100',1,'Rimando Corp.',1,'Petty Cash');
UNLOCK TABLES;
DROP TABLE IF EXISTS `disposal`;
CREATE TABLE `disposal` (
  `disposal_id` int(11) NOT NULL AUTO_INCREMENT,
  `disposal_date` date NOT NULL,
  `disposal_qty` int(11) NOT NULL,
  `disposal_matname` int(11) NOT NULL,
  `disposal_remarks` varchar(65) NOT NULL,
  PRIMARY KEY (`disposal_id`),
  UNIQUE KEY `disposal_id_UNIQUE` (`disposal_id`),
  KEY `disposalmatname_idx` (`disposal_matname`),
  CONSTRAINT `disposalmatname` FOREIGN KEY (`disposal_matname`) REFERENCES `materials` (`mat_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;
LOCK TABLES `disposal` WRITE;
INSERT INTO `disposal` VALUES (1,'2019-07-23',400,1,'Broken '),(2,'2019-06-11',20,2,'Disabled Nut'),(3,'2019-02-28',18,5,'Loose'),(4,'2019-02-16',35,3,'Broken'),(5,'2019-04-21',10,4,'Broken'),(6,'2019-03-22',25,5,'Poured'),(7,'2019-05-13',50,6,'Broken'),(8,'2019-04-28',75,7,'Rusty'),(9,'2019-06-02',25,8,'Loose'),(10,'2019-01-31',65,9,'Rusty'),(11,'2019-02-28',80,10,'Broken'),(12,'2019-07-11',10,1,'Disabled nut'),(13,'2019-08-25',56,1,'Rusty'),(14,'2019-11-25',75,2,'Loose'),(15,'2019-12-26',81,3,'Broken');
UNLOCK TABLES;
DROP TABLE IF EXISTS `returns`;
CREATE TABLE `returns` (
  `returns_id` int(11) NOT NULL AUTO_INCREMENT,
  `returns_matname` int(11) NOT NULL,
  `returns_returnedqty` int(11) NOT NULL,
  `returns_date` date NOT NULL,
  `returns_status` varchar(45) NOT NULL,
  `returns_returningqty` int(11) NOT NULL,
  PRIMARY KEY (`returns_id`),
  UNIQUE KEY `returns_id_UNIQUE` (`returns_id`),
  KEY `returnsmatname_idx` (`returns_matname`),
  CONSTRAINT `returnshauling` FOREIGN KEY (`returns_id`) REFERENCES `hauling` (`hauling_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `returnsmatname` FOREIGN KEY (`returns_matname`) REFERENCES `hauling` (`hauling_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;
LOCK TABLES `returns` WRITE;
INSERT INTO `returns` VALUES (1,1,20,'2019-04-13','Incomplete',15),(2,2,50,'2019-03-18','Complete',50),(3,3,39,'2019-05-13','Incomplete',30),(4,4,60,'2019-06-02','Complete',60),(5,5,35,'2019-05-28','Incomplete',29),(6,6,100,'2019-02-12','Complete',100),(7,7,45,'2019-04-11','Incomplete',30),(8,8,80,'2019-02-02','Complete',80),(9,9,120,'2019-04-19','Incomplete',100),(10,10,40,'2019-01-30','Complete',40),(11,11,95,'2019-05-05','Incomplete',80),(12,12,70,'2019-02-14','Complete',61),(13,13,60,'2019-11-25','Incomplete',20),(14,14,12,'2019-09-21','Complete',5),(15,15,1,'2019-05-30','Complete',1);
UNLOCK TABLES;
DROP TABLE IF EXISTS `returnhistory`;
CREATE TABLE `returnhistory` (
  `returnHistory_id` int(11) NOT NULL AUTO_INCREMENT,
  `returnHistory_material` int(11) NOT NULL,
  PRIMARY KEY (`returnHistory_id`),
  UNIQUE KEY `returnHistory_id_UNIQUE` (`returnHistory_id`),
  KEY `returnhistoryMatname_idx` (`returnHistory_material`),
  CONSTRAINT `returnhistoryMatname` FOREIGN KEY (`returnHistory_material`) REFERENCES `returns` (`returns_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
LOCK TABLES `returnhistory` WRITE;
UNLOCK TABLES;